export interface Player {
  ign: string; // In-Game Name
  uid: string; // Free Fire numeric UID
  role?: 'Rusher' | 'Sniper' | 'Flanker' | 'IGL' | 'Support';
}

export interface TeamSlot {
  slotNumber: number; // 1 to 12
  teamName: string;
  teamTag: string;
  captainName: string;
  captainPhone: string;
  captainUid: string;
  players: Player[];
  substitute?: Player;
  isConfirmed: boolean;
  registeredAt?: string;
  logoColor?: string;
}

export interface TeamMatchScore {
  teamName: string;
  slotNumber: number;
  placement: number; // 1 to 12
  kills: number;
  placementPoints: number;
  killPoints: number;
  totalPoints: number;
  isBooyah: boolean;
  mvpPlayer?: string;
  mvpKills?: number;
}

export interface Match {
  id: string;
  matchNumber: number;
  map: 'Bermuda' | 'Purgatory' | 'Kalahari' | 'Alpine' | 'Nexterra';
  startTime: string;
  isCompleted: boolean;
  results: TeamMatchScore[];
  matchMvp?: {
    playerIgn: string;
    teamName: string;
    kills: number;
    damage?: number;
  };
  proofImage?: string;
  notes?: string;
}

export interface OverallTeamStanding {
  rank: number;
  slotNumber: number;
  teamName: string;
  teamTag: string;
  captainName: string;
  matchesPlayed: number;
  booyahs: number;
  placementPoints: number;
  killPoints: number;
  totalPoints: number;
  prizeMoney?: string;
}

export interface ScoringSystem {
  placements: Record<number, number>; // rank -> points
  killPoint: number; // usually 1
}

export interface CustomRoomConfig {
  roomId: string;
  roomPassword: string;
  isPublished: boolean;
  matchDate: string;
  matchTime: string;
  serverRegion: string;
  gameMode: string; // Battle Royale Squad, Clash Squad
  gunAttributes: boolean;
  characterSkill: boolean;
  limitedAmmo: boolean;
  fallDamage: boolean;
  airdrop: boolean;
  instructions: string;
}

export interface RegistrationRequest {
  id: string;
  teamName: string;
  teamTag: string;
  captainName: string;
  captainPhone: string;
  captainUid: string;
  player1: { ign: string; uid: string };
  player2: { ign: string; uid: string };
  player3: { ign: string; uid: string };
  player4: { ign: string; uid: string };
  substitute?: { ign: string; uid: string };
  submittedAt: string;
  status: 'pending' | 'approved' | 'rejected';
}

export interface Tournament {
  id: string;
  title: string;
  seasonOrEdition: string;
  organizerName: string;
  organizerContact: string;
  status: 'upcoming' | 'live' | 'completed';
  format: 'Battle Royale Squad (12 Slots)' | 'Clash Squad (8 Teams)' | 'Duo Battle (24 Slots)';
  maxSlots: number;
  totalPrizePool: string;
  prizes: {
    firstPlace: string;
    secondPlace: string;
    thirdPlace: string;
    mvpPrize?: string;
  };
  entryFee: string;
  scoringSystem: ScoringSystem;
  roomConfig: CustomRoomConfig;
  slots: TeamSlot[];
  matches: Match[];
  pendingRequests: RegistrationRequest[];
  adminPin: string; // default 7860
}
