import { Match, OverallTeamStanding, ScoringSystem, TeamSlot, Tournament } from '../types/tournament';

export const DEFAULT_FREE_FIRE_SCORING: ScoringSystem = {
  placements: {
    1: 12, // Booyah!
    2: 9,
    3: 8,
    4: 7,
    5: 6,
    6: 5,
    7: 4,
    8: 3,
    9: 2,
    10: 1,
    11: 0,
    12: 0,
  },
  killPoint: 1,
};

/**
 * Calculates overall standings across all completed matches in a tournament.
 */
export function calculateOverallStandings(
  slots: TeamSlot[],
  matches: Match[],
  scoringSystem: ScoringSystem = DEFAULT_FREE_FIRE_SCORING,
  prizes?: Tournament['prizes']
): OverallTeamStanding[] {
  const standingsMap = new Map<number, OverallTeamStanding>();

  // Initialize for all assigned slots
  slots.forEach((slot) => {
    if (slot.teamName && slot.teamName.trim() !== '') {
      standingsMap.set(slot.slotNumber, {
        rank: 1,
        slotNumber: slot.slotNumber,
        teamName: slot.teamName,
        teamTag: slot.teamTag || `S${slot.slotNumber}`,
        captainName: slot.captainName || 'Captain',
        matchesPlayed: 0,
        booyahs: 0,
        placementPoints: 0,
        killPoints: 0,
        totalPoints: 0,
      });
    }
  });

  // Tally completed matches
  matches.forEach((match) => {
    if (!match.isCompleted) return;

    match.results.forEach((res) => {
      const existing = standingsMap.get(res.slotNumber);
      if (existing) {
        existing.matchesPlayed += 1;
        if (res.placement === 1) {
          existing.booyahs += 1;
        }
        existing.placementPoints += res.placementPoints;
        existing.killPoints += res.killPoints;
        existing.totalPoints += res.totalPoints;
      }
    });
  });

  // Sort standings with official Free Fire tie-breaker:
  // 1. Total Points
  // 2. Booyahs
  // 3. Placement Points
  // 4. Kill Points
  const sorted = Array.from(standingsMap.values()).sort((a, b) => {
    if (b.totalPoints !== a.totalPoints) {
      return b.totalPoints - a.totalPoints;
    }
    if (b.booyahs !== a.booyahs) {
      return b.booyahs - a.booyahs;
    }
    if (b.placementPoints !== a.placementPoints) {
      return b.placementPoints - a.placementPoints;
    }
    return b.killPoints - a.killPoints;
  });

  // Assign ranks & prizes
  return sorted.map((item, index) => {
    const rank = index + 1;
    let prizeMoney: string | undefined = undefined;
    if (prizes) {
      if (rank === 1) prizeMoney = prizes.firstPlace;
      else if (rank === 2) prizeMoney = prizes.secondPlace;
      else if (rank === 3) prizeMoney = prizes.thirdPlace;
    }
    return {
      ...item,
      rank,
      prizeMoney,
    };
  });
}

/**
 * Formats overall standings into a text table ready to copy & paste into WhatsApp or Discord groups.
 */
export function generateWhatsAppPointsTable(
  tournament: Tournament,
  standings: OverallTeamStanding[]
): string {
  const completedMatches = tournament.matches.filter((m) => m.isCompleted).length;
  
  let text = `🔥 *${tournament.title.toUpperCase()}* 🔥\n`;
  text += `🏆 *OVERALL POINTS TABLE - MATCHES: ${completedMatches}/${tournament.matches.length}*\n`;
  text += `💰 Prize Pool: ${tournament.totalPrizePool} | Organizer: ${tournament.organizerName}\n`;
  text += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
  text += `*#   TEAM NAME       BYH  PLC  KIL  TOT*\n`;
  text += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;

  standings.forEach((s) => {
    const rankStr = s.rank < 10 ? `${s.rank} ` : `${s.rank}`;
    const namePadded = s.teamName.padEnd(14, ' ').substring(0, 14);
    const booyahStr = String(s.booyahs).padStart(3, ' ');
    const plcStr = String(s.placementPoints).padStart(4, ' ');
    const killStr = String(s.killPoints).padStart(4, ' ');
    const totStr = String(s.totalPoints).padStart(4, ' ');

    let badge = ' ';
    if (s.rank === 1) badge = '🥇';
    else if (s.rank === 2) badge = '🥈';
    else if (s.rank === 3) badge = '🥉';

    text += `${badge}${rankStr} ${namePadded} ${booyahStr} ${plcStr} ${killStr} *${totStr}*\n`;
  });

  text += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
  text += `🎯 Point System: #1=12 | #2=9 | #3=8 | #4=7 | #5=6 | #6=5 | #7=4 | #8=3 | #9=2 | #10=1 | Kill=1pt\n`;
  if (tournament.prizes.firstPlace) {
    text += `👑 1st: ${tournament.prizes.firstPlace} | 🥈 2nd: ${tournament.prizes.secondPlace} | 🥉 3rd: ${tournament.prizes.thirdPlace}\n`;
  }
  text += `Powered by Free Fire Tournament Manager\n`;

  return text;
}

/**
 * Formats the 12-slot list for WhatsApp/Discord sharing.
 */
export function generateWhatsAppSlotList(tournament: Tournament): string {
  let text = `🎮 *${tournament.title.toUpperCase()} - CONFIRMED SLOTS* 🎮\n`;
  text += `📅 Date: ${tournament.roomConfig.matchDate} | Time: ${tournament.roomConfig.matchTime}\n`;
  text += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;

  tournament.slots.forEach((slot) => {
    const slotStr = slot.slotNumber < 10 ? `Slot 0${slot.slotNumber}` : `Slot ${slot.slotNumber}`;
    if (slot.teamName && slot.teamName.trim() !== '') {
      text += `✅ *${slotStr}*: ${slot.teamName} [Tag: ${slot.teamTag || 'N/A'}] (C: ${slot.captainName})\n`;
    } else {
      text += `⭕ *${slotStr}*: [AVAILABLE / OPEN]\n`;
    }
  });

  text += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
  text += `⚠️ *ROOM RULES:*\n`;
  text += `• Room ID & Password will be released 15 mins before match.\n`;
  text += `• Only registered players allowed in designated slots.\n`;
  text += `• No hacking, teaming, or emulator (unless approved).\n`;
  text += `For registration or support contact: ${tournament.organizerContact || 'Tournament Admin'}\n`;

  return text;
}
