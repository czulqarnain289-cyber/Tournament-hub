import React, { useState, useEffect } from 'react';
import { Tournament, Match, TeamSlot, RegistrationRequest, CustomRoomConfig } from './types/tournament';
import { INITIAL_TOURNAMENT } from './data/initialData';
import { calculateOverallStandings } from './utils/scoring';
import { Navbar } from './components/Navbar';
import { TournamentHeader } from './components/TournamentHeader';
import { LeaderboardView } from './components/LeaderboardView';
import { SlotListView } from './components/SlotListView';
import { RoomCredentialsCard } from './components/RoomCredentialsCard';
import { MatchScorerModal } from './components/MatchScorerModal';
import { RegistrationModal } from './components/RegistrationModal';
import { PendingRequestsDrawer } from './components/PendingRequestsDrawer';
import { TournamentSettingsModal } from './components/TournamentSettingsModal';
import { AdminAuthModal } from './components/AdminAuthModal';
import { ShareExportModal } from './components/ShareExportModal';
import { PWAInstallModal } from './components/PWAInstallModal';
import { PlayerInviteModal } from './components/PlayerInviteModal';
import { Shield, Sparkles, CheckCircle2, Lock } from 'lucide-react';

const STORAGE_KEY = 'ff_tournament_master_v1';

export default function App() {
  // Load from localStorage or initialize with rich realistic tournament
  const [tournament, setTournament] = useState<Tournament>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {
      console.error('Failed to load saved tournament state', e);
    }
    return INITIAL_TOURNAMENT;
  });

  // Save to localStorage on any state change
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(tournament));
    } catch (e) {
      console.error('Failed to save tournament state', e);
    }
  }, [tournament]);

  // UI state - default to Player View for external links, remember host login in session
  const [activeTab, setActiveTab] = useState<'standings' | 'slots' | 'room' | 'register'>('standings');
  const [isAdmin, setIsAdmin] = useState<boolean>(() => {
    try {
      return sessionStorage.getItem('ff_host_logged_in') === 'true';
    } catch {
      return false;
    }
  });
  const [lang, setLang] = useState<'en' | 'ur'>('ur'); // Default to Urdu/Roman Urdu since user speaks Urdu

  // Handle URL hash on load (e.g., #register opens squad registration form directly!)
  useEffect(() => {
    const handleHash = () => {
      const hash = window.location.hash.toLowerCase();
      if (hash === '#register') {
        setActiveTab('register');
        setIsRegisterOpen(true);
      } else if (hash === '#room') {
        setActiveTab('room');
      } else if (hash === '#slots') {
        setActiveTab('slots');
      } else if (hash === '#standings' || hash === '#results') {
        setActiveTab('standings');
      }
    };

    handleHash();
    window.addEventListener('hashchange', handleHash);
    return () => window.removeEventListener('hashchange', handleHash);
  }, []);

  // Modals
  const [isAdminAuthOpen, setIsAdminAuthOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isScorerOpen, setIsScorerOpen] = useState(false);
  const [isRegisterOpen, setIsRegisterOpen] = useState(false);
  const [isPendingOpen, setIsPendingOpen] = useState(false);
  const [isShareOpen, setIsShareOpen] = useState(false);
  const [isInstallOpen, setIsInstallOpen] = useState(false);
  const [isInviteOpen, setIsInviteOpen] = useState(false);

  // Active match being edited (null for new match)
  const [editingMatch, setEditingMatch] = useState<Match | null>(null);

  // Toast notification
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Calculate live overall standings
  const standings = calculateOverallStandings(
    tournament.slots,
    tournament.matches,
    tournament.scoringSystem,
    tournament.prizes
  );

  // Admin match actions
  const handleSaveMatch = (match: Match) => {
    setTournament((prev) => {
      const matchIndex = prev.matches.findIndex((m) => m.id === match.id);
      let updatedMatches: Match[];
      if (matchIndex >= 0) {
        updatedMatches = [...prev.matches];
        updatedMatches[matchIndex] = match;
      } else {
        updatedMatches = [...prev.matches, match];
      }
      return {
        ...prev,
        matches: updatedMatches,
      };
    });
    showToast(`Match #${match.matchNumber} (${match.map}) scores recorded!`);
  };

  const handleDeleteMatch = (matchId: string) => {
    if (!confirm('Are you sure you want to delete this match record?')) return;
    setTournament((prev) => ({
      ...prev,
      matches: prev.matches.filter((m) => m.id !== matchId),
    }));
    showToast('Match record deleted.');
  };

  const handleOpenEditMatch = (match: Match) => {
    setEditingMatch(match);
    setIsScorerOpen(true);
  };

  const handleOpenNewMatch = () => {
    setEditingMatch(null);
    setIsScorerOpen(true);
  };

  // Slot Management
  const handleUpdateSlot = (updatedSlot: TeamSlot) => {
    setTournament((prev) => ({
      ...prev,
      slots: prev.slots.map((s) => (s.slotNumber === updatedSlot.slotNumber ? updatedSlot : s)),
    }));
    showToast(`Slot #${updatedSlot.slotNumber} updated for ${updatedSlot.teamName}!`);
  };

  const handleClearSlot = (slotNumber: number) => {
    setTournament((prev) => ({
      ...prev,
      slots: prev.slots.map((s) =>
        s.slotNumber === slotNumber
          ? {
              slotNumber,
              teamName: '',
              teamTag: '',
              captainName: '',
              captainPhone: '',
              captainUid: '',
              players: [],
              isConfirmed: false,
            }
          : s
      ),
    }));
    showToast(`Slot #${slotNumber} is now open.`);
  };

  // Room Config
  const handleUpdateRoomConfig = (newConfig: CustomRoomConfig) => {
    setTournament((prev) => ({
      ...prev,
      roomConfig: newConfig,
    }));
    showToast('Custom Room details updated!');
  };

  // Squad Registration Requests
  const handleSubmitRegistration = (req: RegistrationRequest) => {
    setTournament((prev) => ({
      ...prev,
      pendingRequests: [req, ...prev.pendingRequests],
    }));
    showToast(`Registration request received for ${req.teamName}!`);
  };

  const handleApproveRequest = (requestId: string, slotNumber: number) => {
    const targetReq = tournament.pendingRequests.find((r) => r.id === requestId);
    if (!targetReq) return;

    const newSlot: TeamSlot = {
      slotNumber,
      teamName: targetReq.teamName,
      teamTag: targetReq.teamTag,
      captainName: targetReq.captainName,
      captainPhone: targetReq.captainPhone,
      captainUid: targetReq.captainUid,
      players: [
        { ign: targetReq.player1.ign, uid: targetReq.player1.uid, role: 'Rusher' },
        { ign: targetReq.player2.ign, uid: targetReq.player2.uid, role: 'Sniper' },
        { ign: targetReq.player3.ign, uid: targetReq.player3.uid, role: 'Flanker' },
        { ign: targetReq.player4.ign, uid: targetReq.player4.uid, role: 'Support' },
      ],
      substitute: targetReq.substitute
        ? { ign: targetReq.substitute.ign, uid: targetReq.substitute.uid }
        : undefined,
      isConfirmed: true,
      registeredAt: new Date().toISOString().split('T')[0],
      logoColor: '#f59e0b',
    };

    setTournament((prev) => ({
      ...prev,
      slots: prev.slots.map((s) => (s.slotNumber === slotNumber ? newSlot : s)),
      pendingRequests: prev.pendingRequests.filter((r) => r.id !== requestId),
    }));

    showToast(`Approved ${targetReq.teamName} into Slot #${slotNumber}!`);
  };

  const handleRejectRequest = (requestId: string) => {
    setTournament((prev) => ({
      ...prev,
      pendingRequests: prev.pendingRequests.filter((r) => r.id !== requestId),
    }));
    showToast('Registration declined.');
  };

  // Resets
  const handleResetToDemo = () => {
    setTournament(INITIAL_TOURNAMENT);
    showToast('Tournament reset to demo state.');
  };

  const handleResetToEmpty = () => {
    const emptySlots: TeamSlot[] = Array.from({ length: 12 }, (_, i) => ({
      slotNumber: i + 1,
      teamName: '',
      teamTag: '',
      captainName: '',
      captainPhone: '',
      captainUid: '',
      players: [],
      isConfirmed: false,
    }));

    setTournament({
      ...INITIAL_TOURNAMENT,
      id: `ff-tourney-${Date.now()}`,
      title: 'Free Fire Grand Championship',
      seasonOrEdition: 'Season 1',
      slots: emptySlots,
      matches: [],
      pendingRequests: [],
    });
    showToast('Created new clean tournament.');
  };

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col font-sans selection:bg-amber-500/30 selection:text-amber-200">
      {/* Toast Bar */}
      {toastMessage && (
        <div className="fixed bottom-5 right-5 z-50 px-4 py-2.5 rounded-xl bg-neutral-900 border border-amber-500/50 text-white text-xs font-mono font-bold shadow-2xl flex items-center gap-2 animate-bounce">
          <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Bar Contract (3 zones) */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        isAdmin={isAdmin}
        onOpenAdminLogin={() => setIsAdminAuthOpen(true)}
        onLockAdmin={() => {
          try {
            sessionStorage.removeItem('ff_host_logged_in');
          } catch {}
          setIsAdmin(false);
          showToast('Switched to Public Player View.');
        }}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenNewMatch={handleOpenNewMatch}
        onOpenInstallModal={() => setIsInstallOpen(true)}
        onOpenInviteModal={() => setIsInviteOpen(true)}
        pendingCount={tournament.pendingRequests.length}
        onOpenPendingRequests={() => setIsPendingOpen(true)}
        lang={lang}
        setLang={setLang}
      />

      {/* Main Content Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Organizer Mode Indicator Bar (when admin is unlocked) */}
        {isAdmin && (
          <div className="mb-4 px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500/10 via-orange-500/10 to-transparent border border-amber-500/30 flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2 font-mono text-amber-300">
              <Shield className="w-4 h-4 text-amber-400 shrink-0" />
              <span>
                <strong>{lang === 'ur' ? 'HOST CONTROL ACTIVE HAI:' : 'HOST MANAGEMENT SYSTEM ACTIVE:'}</strong>{' '}
                {lang === 'ur'
                  ? 'Slots, Room ID aur Match Results aapke mukammal control me hain.'
                  : 'You have full authorization to edit slots, enter match scores & toggle room credentials.'}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setIsSettingsOpen(true)}
                className="text-amber-400 hover:text-amber-300 font-mono font-bold underline text-[11px]"
              >
                {lang === 'ur' ? 'Tournament Info Edit Karein' : 'Edit Tourney Info'}
              </button>
              <span className="text-neutral-600">·</span>
              <button
                onClick={() => setIsAdmin(false)}
                className="text-neutral-400 hover:text-white font-mono text-[11px]"
              >
                {lang === 'ur' ? 'Player View Dekhein' : 'Preview as Player'}
              </button>
            </div>
          </div>
        )}

        {/* Hero Banner & 4-Column Quick Metric Strip */}
        <TournamentHeader
          tournament={tournament}
          standings={standings}
          isAdmin={isAdmin}
          onOpenSettings={() => setIsSettingsOpen(true)}
          onOpenNewMatch={handleOpenNewMatch}
          onOpenShare={() => setIsShareOpen(true)}
          onOpenInstallModal={() => setIsInstallOpen(true)}
          onOpenInviteModal={() => setIsInviteOpen(true)}
          lang={lang}
        />

        {/* Dynamic View Sections */}
        {activeTab === 'standings' && (
          <LeaderboardView
            tournament={tournament}
            standings={standings}
            isAdmin={isAdmin}
            onEditMatch={handleOpenEditMatch}
            onDeleteMatch={handleDeleteMatch}
            onOpenNewMatch={handleOpenNewMatch}
            onOpenShare={() => setIsShareOpen(true)}
            lang={lang}
          />
        )}

        {activeTab === 'slots' && (
          <SlotListView
            tournament={tournament}
            isAdmin={isAdmin}
            onUpdateSlot={handleUpdateSlot}
            onClearSlot={handleClearSlot}
            onOpenRegisterModal={() => setIsRegisterOpen(true)}
            lang={lang}
          />
        )}

        {activeTab === 'room' && (
          <RoomCredentialsCard
            roomConfig={tournament.roomConfig}
            tournamentTitle={tournament.title}
            isAdmin={isAdmin}
            onUpdateRoomConfig={handleUpdateRoomConfig}
            lang={lang}
          />
        )}

        {activeTab === 'register' && (
          <div className="rounded-2xl border border-neutral-800 bg-neutral-900/90 p-6 shadow-xl">
            <div className="max-w-2xl mx-auto text-center py-6 space-y-4">
              <div className="w-16 h-16 rounded-2xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-500 mx-auto">
                <Sparkles className="w-8 h-8" />
              </div>
              <h2 className="text-3xl font-black text-white font-display uppercase tracking-wide">
                {lang === 'ur' ? 'Free Fire Squad Registration' : 'Free Fire Squad Registration'}
              </h2>
              <p className="text-xs text-neutral-400 font-mono max-w-lg mx-auto">
                {lang === 'ur'
                  ? 'Tournament me hissa lene ke liye apna squad register karein. Host verification ke baad slot number allot karega.'
                  : 'Register your 4-player competitive roster. Once submitted, the tournament organizer will verify player UIDs and assign your official room slot.'}
              </p>
              <div className="pt-2">
                <button
                  onClick={() => setIsRegisterOpen(true)}
                  className="px-8 py-3 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-neutral-950 font-bold rounded-xl text-sm font-display uppercase tracking-wider shadow-lg shadow-orange-500/20"
                >
                  {lang === 'ur' ? 'Abhi Form Open Karein' : 'Open Registration Form'}
                </button>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Quiet Footer */}
      <footer className="mt-auto border-t border-neutral-900 py-6 text-center text-xs text-neutral-500 font-mono">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>{tournament.title} · Official Tournament System</span>
          <span>Organizer: {tournament.organizerName} ({tournament.organizerContact})</span>
        </div>
      </footer>

      {/* MODALS */}
      <AdminAuthModal
        isOpen={isAdminAuthOpen}
        onClose={() => setIsAdminAuthOpen(false)}
        onSuccess={() => {
          try {
            sessionStorage.setItem('ff_host_logged_in', 'true');
          } catch {}
          setIsAdmin(true);
          setIsAdminAuthOpen(false);
          showToast('Admin Control Panel Unlocked!');
        }}
        correctPin={tournament.adminPin}
        lang={lang}
      />

      <TournamentSettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        tournament={tournament}
        onSaveTournament={(updated) => {
          setTournament(updated);
          showToast('Tournament settings saved successfully!');
        }}
        onResetToDemo={handleResetToDemo}
        onResetToEmpty={handleResetToEmpty}
        lang={lang}
      />

      <MatchScorerModal
        isOpen={isScorerOpen}
        onClose={() => setIsScorerOpen(false)}
        onSaveMatch={handleSaveMatch}
        slots={tournament.slots}
        scoringSystem={tournament.scoringSystem}
        existingMatch={editingMatch}
        matchNumberToCreate={tournament.matches.length + 1}
        lang={lang}
      />

      <RegistrationModal
        isOpen={isRegisterOpen}
        onClose={() => setIsRegisterOpen(false)}
        onSubmitRequest={handleSubmitRegistration}
        hostPhone={tournament.organizerContact}
        tournamentTitle={tournament.title}
        lang={lang}
      />

      <PendingRequestsDrawer
        isOpen={isPendingOpen}
        onClose={() => setIsPendingOpen(false)}
        requests={tournament.pendingRequests}
        slots={tournament.slots}
        onApprove={handleApproveRequest}
        onReject={handleRejectRequest}
        lang={lang}
      />

      <ShareExportModal
        isOpen={isShareOpen}
        onClose={() => setIsShareOpen(false)}
        tournament={tournament}
        standings={standings}
        lang={lang}
      />

      <PlayerInviteModal
        isOpen={isInviteOpen}
        onClose={() => setIsInviteOpen(false)}
        tournament={tournament}
        lang={lang}
      />

      <PWAInstallModal
        isOpen={isInstallOpen}
        onClose={() => setIsInstallOpen(false)}
        lang={lang}
      />
    </div>
  );
}
