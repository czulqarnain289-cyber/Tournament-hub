import React, { useState } from 'react';
import { TeamSlot, Player, Tournament } from '../types/tournament';
import { generateWhatsAppSlotList } from '../utils/scoring';
import { Users, Phone, UserCheck, Edit2, Trash2, Copy, Check, Plus, ShieldAlert, ArrowUpDown } from 'lucide-react';

interface SlotListViewProps {
  tournament: Tournament;
  isAdmin: boolean;
  onUpdateSlot: (updatedSlot: TeamSlot) => void;
  onClearSlot: (slotNumber: number) => void;
  onOpenRegisterModal: () => void;
  lang: 'en' | 'ur';
}

export const SlotListView: React.FC<SlotListViewProps> = ({
  tournament,
  isAdmin,
  onUpdateSlot,
  onClearSlot,
  onOpenRegisterModal,
  lang,
}) => {
  const [copied, setCopied] = useState(false);
  const [editingSlot, setEditingSlot] = useState<TeamSlot | null>(null);
  const [swapSlotSource, setSwapSlotSource] = useState<number | null>(null);

  const filledCount = tournament.slots.filter((s) => s.teamName && s.teamName.trim() !== '').length;

  const handleCopyWhatsApp = () => {
    const text = generateWhatsAppSlotList(tournament);
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingSlot) return;
    onUpdateSlot(editingSlot);
    setEditingSlot(null);
  };

  return (
    <div className="space-y-6">
      {/* Action Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-xl border border-neutral-800 bg-neutral-900/90">
        <div>
          <div className="flex items-center gap-2">
            <Users className="w-5 h-5 text-amber-500" />
            <h2 className="text-xl font-bold text-white font-display uppercase tracking-wide">
              Tournament Slots List (1 to 12)
            </h2>
          </div>
          <p className="text-xs text-neutral-400 mt-0.5">
            {filledCount} / {tournament.maxSlots} Slots confirmed · Tamam squads apne assigned slot me enter hon
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopyWhatsApp}
            className="px-3.5 py-2 text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg flex items-center gap-2 transition-all shadow-sm font-mono"
          >
            {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            <span>{copied ? 'Copied Slot List!' : 'Copy for WhatsApp'}</span>
          </button>

          {!isAdmin && filledCount < tournament.maxSlots && (
            <button
              onClick={onOpenRegisterModal}
              className="px-3.5 py-2 text-xs font-bold bg-amber-500 hover:bg-amber-400 text-neutral-950 rounded-lg flex items-center gap-1.5 transition-colors font-display uppercase tracking-wider"
            >
              <Plus className="w-4 h-4" />
              <span>Register Your Squad</span>
            </button>
          )}
        </div>
      </div>

      {/* 12 Slots Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {tournament.slots.map((slot) => {
          const isAssigned = slot.teamName && slot.teamName.trim() !== '';

          return (
            <div
              key={slot.slotNumber}
              className={`relative rounded-xl border p-4 transition-all ${
                isAssigned
                  ? 'border-neutral-800 bg-neutral-900/90 hover:border-amber-500/40'
                  : 'border-dashed border-neutral-800 bg-neutral-950/40'
              }`}
            >
              {/* Header: Slot Badge & Team Name */}
              <div className="flex items-start justify-between gap-3 mb-3 pb-2.5 border-b border-neutral-800/80">
                <div className="flex items-center gap-2.5">
                  <div
                    className={`w-8 h-8 rounded-lg flex items-center justify-center font-mono font-bold text-xs ${
                      isAssigned
                        ? 'bg-amber-500/15 border border-amber-500/30 text-amber-400'
                        : 'bg-neutral-800 text-neutral-500'
                    }`}
                  >
                    #{slot.slotNumber < 10 ? `0${slot.slotNumber}` : slot.slotNumber}
                  </div>
                  <div>
                    {isAssigned ? (
                      <div className="font-bold text-white text-sm font-sans flex items-center gap-1.5">
                        <span className="truncate max-w-[150px]">{slot.teamName}</span>
                        {slot.teamTag && (
                          <span className="text-[10px] font-mono px-1.5 py-0.2 bg-neutral-800 text-amber-400 rounded">
                            {slot.teamTag}
                          </span>
                        )}
                      </div>
                    ) : (
                      <div className="text-sm font-mono text-neutral-500 italic">
                        [Empty Slot]
                      </div>
                    )}
                    <div className="text-[11px] text-neutral-400 font-mono">
                      {isAssigned ? `Captain: ${slot.captainName}` : 'Available for registration'}
                    </div>
                  </div>
                </div>

                {/* Admin slot controls */}
                {isAdmin && (
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => setEditingSlot({ ...slot })}
                      className="p-1 text-neutral-400 hover:text-amber-400 hover:bg-neutral-800 rounded transition-colors"
                      title="Edit slot details"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    {isAssigned && (
                      <button
                        onClick={() => {
                          if (confirm(`Remove team "${slot.teamName}" from Slot ${slot.slotNumber}?`)) {
                            onClearSlot(slot.slotNumber);
                          }
                        }}
                        className="p-1 text-neutral-400 hover:text-red-400 hover:bg-neutral-800 rounded transition-colors"
                        title="Clear slot"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                )}
              </div>

              {/* Roster / Players details */}
              {isAssigned ? (
                <div className="space-y-2">
                  <div className="grid grid-cols-2 gap-1.5 text-xs font-mono">
                    {slot.players.map((p, idx) => (
                      <div
                        key={idx}
                        className="p-1.5 rounded bg-neutral-950/60 border border-neutral-800/80"
                      >
                        <div className="text-neutral-200 font-semibold truncate text-[11px]">
                          {p.ign || `Player ${idx + 1}`}
                        </div>
                        <div className="text-[10px] text-neutral-500 truncate">
                          UID: {p.uid || 'N/A'}
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Captain Contact strip */}
                  <div className="flex items-center justify-between pt-2 border-t border-neutral-800/60 text-[11px] text-neutral-400 font-mono">
                    <span className="truncate">UID: {slot.captainUid || 'Verified'}</span>
                    {slot.captainPhone && (
                      <a
                        href={`https://wa.me/${slot.captainPhone.replace(/[^0-9]/g, '')}`}
                        target="_blank"
                        rel="noreferrer"
                        className="text-emerald-400 hover:text-emerald-300 flex items-center gap-1 font-semibold"
                        title="Chat on WhatsApp"
                      >
                        <Phone className="w-3 h-3" />
                        <span>WhatsApp</span>
                      </a>
                    )}
                  </div>
                </div>
              ) : (
                <div className="py-6 text-center">
                  {isAdmin ? (
                    <button
                      onClick={() => setEditingSlot({ ...slot })}
                      className="px-3 py-1.5 text-xs font-bold text-amber-400 border border-amber-500/30 hover:bg-amber-500/10 rounded-lg transition-colors font-mono"
                    >
                      + Assign Team to Slot #{slot.slotNumber}
                    </button>
                  ) : (
                    <div className="text-xs text-neutral-600 font-mono">
                      Slot #{slot.slotNumber} is Open
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* EDIT SLOT MODAL (Admin) */}
      {editingSlot && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-950/80 backdrop-blur-sm animate-fade-in">
          <div className="relative w-full max-w-xl max-h-[90vh] overflow-y-auto bg-neutral-900 border border-neutral-800 rounded-xl p-6 shadow-2xl">
            <h3 className="text-xl font-bold text-white font-display uppercase tracking-wide mb-1">
              {lang === 'ur' ? `Slot #${editingSlot.slotNumber} ki details` : `Edit Slot #${editingSlot.slotNumber}`}
            </h3>
            <p className="text-xs text-neutral-400 mb-4 font-mono">
              Update team roster, captain contact, and player UIDs
            </p>

            <form onSubmit={handleSaveEdit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-mono text-neutral-300 mb-1">Team Name</label>
                  <input
                    type="text"
                    required
                    value={editingSlot.teamName}
                    onChange={(e) => setEditingSlot({ ...editingSlot, teamName: e.target.value })}
                    placeholder="e.g. Total Gaming"
                    className="w-full bg-neutral-950 border border-neutral-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-mono text-neutral-300 mb-1">Team Tag</label>
                  <input
                    type="text"
                    value={editingSlot.teamTag}
                    onChange={(e) => setEditingSlot({ ...editingSlot, teamTag: e.target.value })}
                    placeholder="e.g. TG"
                    className="w-full bg-neutral-950 border border-neutral-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-mono text-neutral-300 mb-1">Captain Name</label>
                  <input
                    type="text"
                    required
                    value={editingSlot.captainName}
                    onChange={(e) => setEditingSlot({ ...editingSlot, captainName: e.target.value })}
                    placeholder="Captain Name"
                    className="w-full bg-neutral-950 border border-neutral-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-mono text-neutral-300 mb-1">WhatsApp / Phone</label>
                  <input
                    type="text"
                    value={editingSlot.captainPhone}
                    onChange={(e) => setEditingSlot({ ...editingSlot, captainPhone: e.target.value })}
                    placeholder="+92 300 1234567"
                    className="w-full bg-neutral-950 border border-neutral-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-mono text-neutral-300 mb-1">Captain Free Fire UID</label>
                  <input
                    type="text"
                    value={editingSlot.captainUid}
                    onChange={(e) => setEditingSlot({ ...editingSlot, captainUid: e.target.value })}
                    placeholder="e.g. 192847192"
                    className="w-full bg-neutral-950 border border-neutral-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              {/* 4 Players Roster */}
              <div className="space-y-2 pt-2">
                <label className="block text-xs font-mono text-amber-400 font-bold uppercase">
                  Squad Players (IGN & Numeric UID)
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {[0, 1, 2, 3].map((idx) => {
                    const player = editingSlot.players[idx] || { ign: '', uid: '' };
                    return (
                      <div key={idx} className="p-2.5 rounded-lg bg-neutral-950 border border-neutral-800 space-y-1.5">
                        <div className="text-[11px] font-mono text-neutral-400 font-semibold">
                          Player #{idx + 1}
                        </div>
                        <input
                          type="text"
                          value={player.ign}
                          onChange={(e) => {
                            const newPlayers = [...editingSlot.players];
                            newPlayers[idx] = { ...player, ign: e.target.value };
                            setEditingSlot({ ...editingSlot, players: newPlayers });
                          }}
                          placeholder="In-Game Name (IGN)"
                          className="w-full bg-neutral-900 border border-neutral-700 rounded px-2.5 py-1 text-xs text-white focus:outline-none focus:border-amber-500"
                        />
                        <input
                          type="text"
                          value={player.uid}
                          onChange={(e) => {
                            const newPlayers = [...editingSlot.players];
                            newPlayers[idx] = { ...player, uid: e.target.value };
                            setEditingSlot({ ...editingSlot, players: newPlayers });
                          }}
                          placeholder="FF Numeric UID"
                          className="w-full bg-neutral-900 border border-neutral-700 rounded px-2.5 py-1 text-xs text-white focus:outline-none focus:border-amber-500 font-mono"
                        />
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-neutral-800">
                <button
                  type="button"
                  onClick={() => setEditingSlot(null)}
                  className="px-4 py-2 text-xs font-semibold text-neutral-400 hover:text-white rounded-lg hover:bg-neutral-800 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold bg-amber-500 hover:bg-amber-400 text-neutral-950 rounded-lg shadow font-display uppercase tracking-wider"
                >
                  Save Slot #{editingSlot.slotNumber}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
