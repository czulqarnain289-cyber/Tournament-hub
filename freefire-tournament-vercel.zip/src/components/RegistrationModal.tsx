import React, { useState } from 'react';
import { RegistrationRequest } from '../types/tournament';
import { PlusCircle, X, Check, Users, Phone, ShieldCheck } from 'lucide-react';

interface RegistrationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmitRequest: (request: RegistrationRequest) => void;
  hostPhone?: string;
  tournamentTitle?: string;
  lang: 'en' | 'ur';
}

export const RegistrationModal: React.FC<RegistrationModalProps> = ({
  isOpen,
  onClose,
  onSubmitRequest,
  hostPhone = '+923001234567',
  tournamentTitle = 'Free Fire Tournament',
  lang,
}) => {
  const [teamName, setTeamName] = useState('');
  const [teamTag, setTeamTag] = useState('');
  const [captainName, setCaptainName] = useState('');
  const [captainPhone, setCaptainPhone] = useState('');
  const [captainUid, setCaptainUid] = useState('');

  const [p1Ign, setP1Ign] = useState('');
  const [p1Uid, setP1Uid] = useState('');

  const [p2Ign, setP2Ign] = useState('');
  const [p2Uid, setP2Uid] = useState('');

  const [p3Ign, setP3Ign] = useState('');
  const [p3Uid, setP3Uid] = useState('');

  const [p4Ign, setP4Ign] = useState('');
  const [p4Uid, setP4Uid] = useState('');

  const [subIgn, setSubIgn] = useState('');
  const [subUid, setSubUid] = useState('');

  const [isSuccess, setIsSuccess] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const newRequest: RegistrationRequest = {
      id: `req-${Date.now()}`,
      teamName,
      teamTag: teamTag || teamName.substring(0, 3).toUpperCase(),
      captainName,
      captainPhone,
      captainUid,
      player1: { ign: p1Ign || captainName, uid: p1Uid || captainUid },
      player2: { ign: p2Ign, uid: p2Uid },
      player3: { ign: p3Ign, uid: p3Uid },
      player4: { ign: p4Ign, uid: p4Uid },
      substitute: subIgn ? { ign: subIgn, uid: subUid } : undefined,
      submittedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      status: 'pending',
    };

    onSubmitRequest(newRequest);
    setIsSuccess(true);
  };

  const handleResetAndClose = () => {
    setIsSuccess(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-neutral-950/85 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-2xl max-h-[92vh] flex flex-col bg-neutral-900 border border-neutral-800 rounded-2xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-800 bg-neutral-950/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-500">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white font-display uppercase tracking-wide">
                {lang === 'ur' ? 'Free Fire Squad Registration' : 'Squad Tournament Registration'}
              </h2>
              <p className="text-xs text-neutral-400 font-mono">
                {lang === 'ur'
                  ? 'Team details darj karein, Admin verify kar ke slot allot karega'
                  : 'Submit squad details. Tournament host will review and allot your slot.'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-neutral-400 hover:text-white p-1.5 rounded-lg hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        {isSuccess ? (
          <div className="p-8 text-center space-y-4">
            <div className="w-16 h-16 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center mx-auto shadow-lg">
              <ShieldCheck className="w-8 h-8" />
            </div>
            <h3 className="text-2xl font-black text-white font-display uppercase tracking-wide">
              {lang === 'ur' ? 'Registration Kamyabi Se Jama Ho Gayi!' : 'Registration Submitted!'}
            </h3>
            <p className="text-xs text-neutral-400 max-w-md mx-auto font-mono">
              {lang === 'ur'
                ? `Team "${teamName}" ki request receive ho gayi hai. Slot ki fori confirmation ke liye neeche diye gaye button se WhatsApp par host ko roster send karein.`
                : `Your team "${teamName}" has been submitted. For instant slot allotment, send your squad roster directly to the host on WhatsApp.`}
            </p>

            <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3">
              <a
                href={`https://wa.me/${hostPhone.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(
                  `🔥 *FREE FIRE SQUAD REGISTRATION* 🔥\nTournament: ${tournamentTitle}\nTeam Name: *${teamName}* [Tag: ${teamTag || 'N/A'}]\nCaptain: ${captainName} (WhatsApp: ${captainPhone}, UID: ${captainUid})\n\n👥 *ROSTER:*\n1. ${p1Ign || captainName} (${p1Uid || captainUid})\n2. ${p2Ign} (${p2Uid})\n3. ${p3Ign} (${p3Uid})\n4. ${p4Ign} (${p4Uid})\n${subIgn ? `Sub: ${subIgn} (${subUid})\n` : ''}\nAdmin please confirm our slot number!`
                )}`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto px-6 py-2.5 text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg shadow-lg font-display uppercase tracking-wider flex items-center justify-center gap-2"
              >
                <Phone className="w-4 h-4" />
                <span>{lang === 'ur' ? 'Host ko WhatsApp par Roster Bhejein' : 'Send Roster to Host on WhatsApp'}</span>
              </a>

              <button
                onClick={handleResetAndClose}
                className="w-full sm:w-auto px-5 py-2.5 text-xs font-semibold text-neutral-300 hover:text-white rounded-lg bg-neutral-800 hover:bg-neutral-700 transition-colors"
              >
                {lang === 'ur' ? 'Slots List Dekhein' : 'View Slots List'}
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-5">
            {/* Team Info */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-mono text-neutral-300 mb-1">
                  Squad Name *
                </label>
                <input
                  type="text"
                  required
                  value={teamName}
                  onChange={(e) => setTeamName(e.target.value)}
                  placeholder="e.g. Total Dominance"
                  className="w-full bg-neutral-950 border border-neutral-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="block text-xs font-mono text-neutral-300 mb-1">
                  Team Tag
                </label>
                <input
                  type="text"
                  maxLength={5}
                  value={teamTag}
                  onChange={(e) => setTeamTag(e.target.value)}
                  placeholder="e.g. TD"
                  className="w-full bg-neutral-950 border border-neutral-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500 uppercase"
                />
              </div>
            </div>

            {/* Captain Info */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 p-4 rounded-xl bg-neutral-950 border border-neutral-800">
              <div>
                <label className="block text-xs font-mono text-neutral-300 mb-1">
                  Captain Name *
                </label>
                <input
                  type="text"
                  required
                  value={captainName}
                  onChange={(e) => setCaptainName(e.target.value)}
                  placeholder="Captain IGN or Name"
                  className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="block text-xs font-mono text-neutral-300 mb-1">
                  Captain WhatsApp # *
                </label>
                <input
                  type="text"
                  required
                  value={captainPhone}
                  onChange={(e) => setCaptainPhone(e.target.value)}
                  placeholder="+92 300 1234567"
                  className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500 font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-mono text-neutral-300 mb-1">
                  Captain Free Fire UID *
                </label>
                <input
                  type="text"
                  required
                  value={captainUid}
                  onChange={(e) => setCaptainUid(e.target.value)}
                  placeholder="e.g. 184920194"
                  className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500 font-mono"
                />
              </div>
            </div>

            {/* Squad Lineup (4 Players) */}
            <div className="space-y-3">
              <label className="block text-xs font-mono text-amber-400 font-bold uppercase">
                Free Fire 4-Player Roster (IGN & Numeric UID)
              </label>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Player 1 */}
                <div className="p-3 rounded-lg bg-neutral-950 border border-neutral-800 space-y-2">
                  <div className="text-[11px] font-mono text-neutral-400 font-bold">Player 1 (Rusher / IGL)</div>
                  <input
                    type="text"
                    required
                    value={p1Ign}
                    onChange={(e) => setP1Ign(e.target.value)}
                    placeholder="Player 1 IGN"
                    className="w-full bg-neutral-900 border border-neutral-700 rounded px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-amber-500"
                  />
                  <input
                    type="text"
                    required
                    value={p1Uid}
                    onChange={(e) => setP1Uid(e.target.value)}
                    placeholder="Numeric FF UID"
                    className="w-full bg-neutral-900 border border-neutral-700 rounded px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-amber-500 font-mono"
                  />
                </div>

                {/* Player 2 */}
                <div className="p-3 rounded-lg bg-neutral-950 border border-neutral-800 space-y-2">
                  <div className="text-[11px] font-mono text-neutral-400 font-bold">Player 2 (Sniper)</div>
                  <input
                    type="text"
                    required
                    value={p2Ign}
                    onChange={(e) => setP2Ign(e.target.value)}
                    placeholder="Player 2 IGN"
                    className="w-full bg-neutral-900 border border-neutral-700 rounded px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-amber-500"
                  />
                  <input
                    type="text"
                    required
                    value={p2Uid}
                    onChange={(e) => setP2Uid(e.target.value)}
                    placeholder="Numeric FF UID"
                    className="w-full bg-neutral-900 border border-neutral-700 rounded px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-amber-500 font-mono"
                  />
                </div>

                {/* Player 3 */}
                <div className="p-3 rounded-lg bg-neutral-950 border border-neutral-800 space-y-2">
                  <div className="text-[11px] font-mono text-neutral-400 font-bold">Player 3 (Flanker)</div>
                  <input
                    type="text"
                    required
                    value={p3Ign}
                    onChange={(e) => setP3Ign(e.target.value)}
                    placeholder="Player 3 IGN"
                    className="w-full bg-neutral-900 border border-neutral-700 rounded px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-amber-500"
                  />
                  <input
                    type="text"
                    required
                    value={p3Uid}
                    onChange={(e) => setP3Uid(e.target.value)}
                    placeholder="Numeric FF UID"
                    className="w-full bg-neutral-900 border border-neutral-700 rounded px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-amber-500 font-mono"
                  />
                </div>

                {/* Player 4 */}
                <div className="p-3 rounded-lg bg-neutral-950 border border-neutral-800 space-y-2">
                  <div className="text-[11px] font-mono text-neutral-400 font-bold">Player 4 (Support)</div>
                  <input
                    type="text"
                    required
                    value={p4Ign}
                    onChange={(e) => setP4Ign(e.target.value)}
                    placeholder="Player 4 IGN"
                    className="w-full bg-neutral-900 border border-neutral-700 rounded px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-amber-500"
                  />
                  <input
                    type="text"
                    required
                    value={p4Uid}
                    onChange={(e) => setP4Uid(e.target.value)}
                    placeholder="Numeric FF UID"
                    className="w-full bg-neutral-900 border border-neutral-700 rounded px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-amber-500 font-mono"
                  />
                </div>
              </div>
            </div>

            {/* Submit Bar */}
            <div className="flex items-center justify-end gap-3 pt-4 border-t border-neutral-800">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs font-semibold text-neutral-400 hover:text-white rounded-lg hover:bg-neutral-800 transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-6 py-2.5 text-xs font-bold bg-amber-500 hover:bg-amber-400 text-neutral-950 rounded-lg shadow-lg font-display uppercase tracking-wider flex items-center gap-2"
              >
                <Check className="w-4 h-4" />
                <span>Submit Squad Application</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
