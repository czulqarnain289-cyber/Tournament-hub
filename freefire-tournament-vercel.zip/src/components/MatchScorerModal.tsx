import React, { useState, useEffect } from 'react';
import { Match, TeamMatchScore, TeamSlot, ScoringSystem } from '../types/tournament';
import { Trophy, Target, X, Check, Sparkles, Award } from 'lucide-react';

interface MatchScorerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveMatch: (match: Match) => void;
  slots: TeamSlot[];
  scoringSystem: ScoringSystem;
  existingMatch?: Match | null;
  matchNumberToCreate: number;
  lang: 'en' | 'ur';
}

export const MatchScorerModal: React.FC<MatchScorerModalProps> = ({
  isOpen,
  onClose,
  onSaveMatch,
  slots,
  scoringSystem,
  existingMatch,
  matchNumberToCreate,
  lang,
}) => {
  const [map, setMap] = useState<'Bermuda' | 'Purgatory' | 'Kalahari' | 'Alpine' | 'Nexterra'>('Bermuda');
  const [startTime, setStartTime] = useState('08:30 PM');
  const [scores, setScores] = useState<TeamMatchScore[]>([]);
  const [mvpIgn, setMvpIgn] = useState('');
  const [mvpTeam, setMvpTeam] = useState('');
  const [mvpKills, setMvpKills] = useState<number>(0);
  const [notes, setNotes] = useState('');

  // Initialize scores whenever modal opens or existingMatch changes
  useEffect(() => {
    if (!isOpen) return;

    if (existingMatch) {
      setMap(existingMatch.map);
      setStartTime(existingMatch.startTime);
      setScores(existingMatch.results);
      setMvpIgn(existingMatch.matchMvp?.playerIgn || '');
      setMvpTeam(existingMatch.matchMvp?.teamName || '');
      setMvpKills(existingMatch.matchMvp?.kills || 0);
      setNotes(existingMatch.notes || '');
    } else {
      setMap('Bermuda');
      setStartTime('08:30 PM');
      setMvpIgn('');
      setMvpTeam('');
      setMvpKills(0);
      setNotes('');

      // Build default scores for all assigned slots
      const initial: TeamMatchScore[] = slots
        .filter((s) => s.teamName && s.teamName.trim() !== '')
        .map((s, idx) => {
          const placement = idx + 1;
          const placementPts = scoringSystem.placements[placement] ?? 0;
          const kills = 0;
          return {
            slotNumber: s.slotNumber,
            teamName: s.teamName,
            placement,
            kills,
            placementPoints: placementPts,
            killPoints: kills * scoringSystem.killPoint,
            totalPoints: placementPts + kills * scoringSystem.killPoint,
            isBooyah: placement === 1,
          };
        });
      setScores(initial);
    }
  }, [isOpen, existingMatch, slots, scoringSystem]);

  if (!isOpen) return null;

  const handleUpdatePlacement = (slotNum: number, newPlacement: number) => {
    setScores((prev) =>
      prev.map((item) => {
        if (item.slotNumber === slotNum) {
          const placementPts = scoringSystem.placements[newPlacement] ?? 0;
          const killPts = item.kills * scoringSystem.killPoint;
          return {
            ...item,
            placement: newPlacement,
            placementPoints: placementPts,
            totalPoints: placementPts + killPts,
            isBooyah: newPlacement === 1,
          };
        }
        return item;
      })
    );
  };

  const handleUpdateKills = (slotNum: number, kills: number) => {
    const validKills = Math.max(0, kills);
    setScores((prev) =>
      prev.map((item) => {
        if (item.slotNumber === slotNum) {
          const killPts = validKills * scoringSystem.killPoint;
          return {
            ...item,
            kills: validKills,
            killPoints: killPts,
            totalPoints: item.placementPoints + killPts,
          };
        }
        return item;
      })
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const matchId = existingMatch ? existingMatch.id : `match-${Date.now()}`;
    const matchNumber = existingMatch ? existingMatch.matchNumber : matchNumberToCreate;

    // Find the #1 team for default MVP team if not set
    const booyahTeam = scores.find((s) => s.placement === 1);

    const updatedMatch: Match = {
      id: matchId,
      matchNumber,
      map,
      startTime,
      isCompleted: true,
      results: scores,
      matchMvp: mvpIgn
        ? {
            playerIgn: mvpIgn,
            teamName: mvpTeam || (booyahTeam ? booyahTeam.teamName : 'Champions'),
            kills: mvpKills || 5,
          }
        : undefined,
      notes: notes || undefined,
    };

    onSaveMatch(updatedMatch);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-neutral-950/85 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-4xl max-h-[92vh] flex flex-col bg-neutral-900 border border-neutral-800 rounded-2xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-800 bg-neutral-950/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-500 font-bold">
              <Trophy className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white font-display uppercase tracking-wide">
                {existingMatch
                  ? `Edit Match #${existingMatch.matchNumber} (${existingMatch.map}) Results`
                  : `Record Match #${matchNumberToCreate} Results`}
              </h2>
              <p className="text-xs text-neutral-400 font-mono">
                {lang === 'ur'
                  ? 'Rank aur Kills enter karein, points auto calculate ho jayenge'
                  : 'Enter placement and kill points. Total points calculate automatically.'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-neutral-400 hover:text-white p-1.5 rounded-lg hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Match Settings Strip */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 p-4 rounded-xl bg-neutral-950 border border-neutral-800">
            <div>
              <label className="block text-xs font-mono text-neutral-400 mb-1 uppercase">Map</label>
              <select
                value={map}
                onChange={(e) => setMap(e.target.value as any)}
                className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500 font-mono font-semibold"
              >
                <option value="Bermuda">Bermuda</option>
                <option value="Purgatory">Purgatory</option>
                <option value="Kalahari">Kalahari</option>
                <option value="Alpine">Alpine</option>
                <option value="Nexterra">Nexterra</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-mono text-neutral-400 mb-1 uppercase">Start Time</label>
              <input
                type="text"
                value={startTime}
                onChange={(e) => setStartTime(e.target.value)}
                placeholder="e.g. 09:00 PM"
                className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500 font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-mono text-neutral-400 mb-1 uppercase">Match Notes</label>
              <input
                type="text"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="e.g. Zone clutch, 1v3 at Clock Tower"
                className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500"
              />
            </div>
          </div>

          {/* Scores Entry Grid */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-bold text-white font-display uppercase tracking-wider flex items-center gap-2">
                <span>🎯</span>
                <span>Team Placement & Kills Input</span>
              </h3>
              <span className="text-xs text-neutral-400 font-mono">
                {scores.length} Squads Active
              </span>
            </div>

            <div className="rounded-xl border border-neutral-800 bg-neutral-950 overflow-hidden shadow-inner">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-neutral-800 bg-neutral-900/80 text-neutral-400 uppercase font-mono text-[11px]">
                      <th className="py-2.5 px-3 w-16">Slot</th>
                      <th className="py-2.5 px-3">Squad Name</th>
                      <th className="py-2.5 px-3 w-28">Rank Place</th>
                      <th className="py-2.5 px-3 w-28">Kill Count</th>
                      <th className="py-2.5 px-3 text-right">Place Pts</th>
                      <th className="py-2.5 px-3 text-right">Kill Pts</th>
                      <th className="py-2.5 px-4 text-right text-amber-400 font-bold">Total Pts</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-800/60 font-mono-numbers">
                    {scores.map((row) => {
                      const isBooyah = row.placement === 1;
                      return (
                        <tr
                          key={row.slotNumber}
                          className={`hover:bg-neutral-900/40 ${
                            isBooyah ? 'bg-amber-500/10' : ''
                          }`}
                        >
                          <td className="py-2.5 px-3 text-neutral-400 font-mono">
                            #{row.slotNumber}
                          </td>
                          <td className="py-2.5 px-3">
                            <span className="font-sans font-bold text-white">
                              {row.teamName}
                            </span>
                            {isBooyah && (
                              <span className="ml-2 text-[10px] text-amber-400 font-mono font-bold">
                                👑 BOOYAH!
                              </span>
                            )}
                          </td>
                          <td className="py-2.5 px-3">
                            <select
                              value={row.placement}
                              onChange={(e) =>
                                handleUpdatePlacement(row.slotNumber, parseInt(e.target.value, 10))
                              }
                              className="w-full bg-neutral-900 border border-neutral-700 rounded px-2 py-1 text-xs text-white focus:outline-none focus:border-amber-500 font-mono"
                            >
                              {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map((rank) => (
                                <option key={rank} value={rank}>
                                  Rank #{rank} {rank === 1 ? '(12 pts)' : ''}
                                </option>
                              ))}
                            </select>
                          </td>
                          <td className="py-2.5 px-3">
                            <input
                              type="number"
                              min={0}
                              max={48}
                              value={row.kills}
                              onChange={(e) =>
                                handleUpdateKills(row.slotNumber, parseInt(e.target.value, 10) || 0)
                              }
                              className="w-full bg-neutral-900 border border-neutral-700 rounded px-2 py-1 text-xs text-white focus:outline-none focus:border-amber-500 font-mono"
                            />
                          </td>
                          <td className="py-2.5 px-3 text-right text-neutral-300 font-mono">
                            {row.placementPoints}
                          </td>
                          <td className="py-2.5 px-3 text-right text-orange-400 font-mono">
                            {row.killPoints}
                          </td>
                          <td className="py-2.5 px-4 text-right text-amber-400 font-black text-sm font-mono">
                            {row.totalPoints}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* Match MVP / Top Fragger Section */}
          <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 space-y-3">
            <div className="flex items-center gap-2">
              <Award className="w-4 h-4 text-amber-500" />
              <h3 className="text-xs font-mono font-bold text-amber-400 uppercase tracking-wider">
                Match MVP / Top Fragger
              </h3>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-[11px] font-mono text-neutral-400 mb-1">
                  Player IGN
                </label>
                <input
                  type="text"
                  value={mvpIgn}
                  onChange={(e) => setMvpIgn(e.target.value)}
                  placeholder="e.g. TD·Killer99"
                  className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-amber-500"
                />
              </div>
              <div>
                <label className="block text-[11px] font-mono text-neutral-400 mb-1">
                  Team Name
                </label>
                <input
                  type="text"
                  value={mvpTeam}
                  onChange={(e) => setMvpTeam(e.target.value)}
                  placeholder="e.g. Total Dominance"
                  className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-amber-500"
                />
              </div>
              <div>
                <label className="block text-[11px] font-mono text-neutral-400 mb-1">
                  Kills in Match
                </label>
                <input
                  type="number"
                  min={0}
                  value={mvpKills}
                  onChange={(e) => setMvpKills(parseInt(e.target.value, 10) || 0)}
                  className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-amber-500 font-mono"
                />
              </div>
            </div>
          </div>

          {/* Footer Save Button */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-neutral-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-neutral-400 hover:text-white rounded-lg hover:bg-neutral-800 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 text-xs font-bold bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-neutral-950 rounded-lg shadow-lg font-display uppercase tracking-wider flex items-center gap-2"
            >
              <Check className="w-4 h-4" />
              <span>Save & Calculate Standings</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
