import React, { useState } from 'react';
import { Tournament } from '../types/tournament';
import {
  Share2,
  Copy,
  Check,
  Send,
  ShieldCheck,
  X,
  AlertTriangle,
  HelpCircle,
  MessageSquare,
  Globe,
  CheckCircle2,
  ExternalLink,
  Download,
  FileArchive,
  UploadCloud,
} from 'lucide-react';

interface PlayerInviteModalProps {
  isOpen: boolean;
  onClose: () => void;
  tournament: Tournament;
  lang: 'en' | 'ur';
}

export const PlayerInviteModal: React.FC<PlayerInviteModalProps> = ({
  isOpen,
  onClose,
  tournament,
  lang,
}) => {
  const defaultBaseUrl = 'https://ais-pre-q34drs72wmsn35odkhk6he-150327431140.asia-southeast1.run.app';
  const [customBaseUrl, setCustomBaseUrl] = useState(defaultBaseUrl);
  const [copiedGeneral, setCopiedGeneral] = useState(false);
  const [copiedRegister, setCopiedRegister] = useState(false);
  const [copiedMessage, setCopiedMessage] = useState(false);
  const [copiedOfflineTemplate, setCopiedOfflineTemplate] = useState(false);
  const [activeTab, setActiveTab] = useState<'vercel_zip' | 'whatsapp_form' | 'fix_error' | 'links'>('vercel_zip');

  if (!isOpen) return null;

  const baseUrl = customBaseUrl.trim() || defaultBaseUrl;
  const registerUrl = `${baseUrl}#register`;
  const resultsUrl = `${baseUrl}#standings`;

  const inviteMessage = `🔥 *${tournament.title.toUpperCase()}* 🔥\n` +
    `🏆 *Free Fire Esports Tournament - Registrations Open!*\n\n` +
    `💰 *Prize Pool:* ${tournament.totalPrizePool}\n` +
    `👑 1st: ${tournament.prizes.firstPlace} | 🥈 2nd: ${tournament.prizes.secondPlace} | 🥉 3rd: ${tournament.prizes.thirdPlace}\n` +
    `📅 *Match Date:* ${tournament.roomConfig.matchDate} at ${tournament.roomConfig.matchTime}\n` +
    `🎮 *Format:* ${tournament.format}\n` +
    `👤 *Host / Organizer:* ${tournament.organizerName} (${tournament.organizerContact})\n\n` +
    `📝 *Apna Squad Register Karne Ke Liye Is Link Par Click Karein:*\n` +
    `👉 ${registerUrl}\n\n` +
    `📊 *Live Results & Points Table Yahan Dekhein:*\n` +
    `👉 ${resultsUrl}\n\n` +
    `⚠️ *Note:* Slots mehdood hain (Total 12 Slots). Jaldi register karein!`;

  const offlineWhatsAppForm = `🔥 *FREE FIRE SQUAD REGISTRATION FORM* 🔥\n` +
    `🏆 Tournament: *${tournament.title}*\n` +
    `💰 Prize Pool: ${tournament.totalPrizePool}\n` +
    `📅 Match Time: ${tournament.roomConfig.matchDate} (${tournament.roomConfig.matchTime})\n\n` +
    `📝 *Neeche di gayi details fill kar ke is number par WhatsApp karein:*\n\n` +
    `🛡️ Squad / Team Name: \n` +
    `🏷️ Team Tag: \n` +
    `👑 Captain Name: \n` +
    `📱 Captain WhatsApp #: \n` +
    `🎮 Captain FF UID: \n\n` +
    `👥 *ROSTER (Player Name + Free Fire UID):*\n` +
    `1. Player 1 (Rusher): \n` +
    `2. Player 2 (Sniper): \n` +
    `3. Player 3 (Flanker): \n` +
    `4. Player 4 (Support): \n` +
    `5. Substitute (Optional): \n\n` +
    `Host (${tournament.organizerName}): Jaldi slot allot karein!`;

  const whatsappShareUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(inviteMessage)}`;
  const whatsappOfflineShareUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(offlineWhatsAppForm)}`;

  const handleCopyGeneral = () => {
    navigator.clipboard.writeText(baseUrl);
    setCopiedGeneral(true);
    setTimeout(() => setCopiedGeneral(false), 2000);
  };

  const handleCopyRegister = () => {
    navigator.clipboard.writeText(registerUrl);
    setCopiedRegister(true);
    setTimeout(() => setCopiedRegister(false), 2000);
  };

  const handleCopyMessage = () => {
    navigator.clipboard.writeText(inviteMessage);
    setCopiedMessage(true);
    setTimeout(() => setCopiedMessage(false), 2500);
  };

  const handleCopyOffline = () => {
    navigator.clipboard.writeText(offlineWhatsAppForm);
    setCopiedOfflineTemplate(true);
    setTimeout(() => setCopiedOfflineTemplate(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-neutral-950/85 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-xl max-h-[92vh] flex flex-col bg-neutral-900 border border-neutral-800 rounded-2xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-800 bg-neutral-950/70">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center text-neutral-950 shadow-md">
              <Share2 className="w-5 h-5 text-neutral-950" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white font-display uppercase tracking-wide">
                {lang === 'ur' ? 'Players ko Tournament Link Bhejein' : 'Player Share & Invite Center'}
              </h2>
              <p className="text-xs text-neutral-400 font-mono">
                {lang === 'ur'
                  ? 'Players invite karein aur error ka fori hal dekhein'
                  : 'Invite players, share registration links, or use direct WhatsApp template'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-neutral-400 hover:text-white p-1.5 rounded-lg hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="px-6 pt-3 flex items-center gap-1 sm:gap-2 border-b border-neutral-800 bg-neutral-950/40 overflow-x-auto">
          <button
            onClick={() => setActiveTab('vercel_zip')}
            className={`px-3 py-2 text-xs font-bold rounded-t-lg transition-colors font-mono flex items-center gap-1.5 border-b-2 whitespace-nowrap ${
              activeTab === 'vercel_zip'
                ? 'border-amber-500 text-amber-400 bg-neutral-900'
                : 'border-transparent text-neutral-400 hover:text-white'
            }`}
          >
            <FileArchive className="w-3.5 h-3.5 text-amber-400" />
            <span>Vercel ZIP Code (Permanent Host)</span>
          </button>
          <button
            onClick={() => setActiveTab('whatsapp_form')}
            className={`px-3 py-2 text-xs font-bold rounded-t-lg transition-colors font-mono flex items-center gap-1.5 border-b-2 whitespace-nowrap ${
              activeTab === 'whatsapp_form'
                ? 'border-emerald-500 text-emerald-400 bg-neutral-900'
                : 'border-transparent text-neutral-400 hover:text-white'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
            <span>Direct WhatsApp Roster</span>
          </button>
          <button
            onClick={() => setActiveTab('fix_error')}
            className={`px-3 py-2 text-xs font-bold rounded-t-lg transition-colors font-mono flex items-center gap-1.5 border-b-2 whitespace-nowrap ${
              activeTab === 'fix_error'
                ? 'border-red-500 text-red-400 bg-neutral-900'
                : 'border-transparent text-neutral-400 hover:text-white'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5 text-red-400" />
            <span>AI Studio Link Help</span>
          </button>
          <button
            onClick={() => setActiveTab('links')}
            className={`px-3 py-2 text-xs font-bold rounded-t-lg transition-colors font-mono flex items-center gap-1.5 border-b-2 whitespace-nowrap ${
              activeTab === 'links'
                ? 'border-blue-500 text-blue-400 bg-neutral-900'
                : 'border-transparent text-neutral-400 hover:text-white'
            }`}
          >
            <Globe className="w-3.5 h-3.5" />
            <span>Web Links</span>
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-5">
          {/* TAB: VERCEL ZIP CODE DEPLOYMENT */}
          {activeTab === 'vercel_zip' && (
            <div className="space-y-4">
              {/* Highlight Announcement */}
              <div className="p-4 rounded-xl bg-gradient-to-r from-amber-500/15 via-orange-500/10 to-amber-500/5 border border-amber-500/30 space-y-2">
                <div className="flex items-center gap-2 text-amber-400 font-bold font-display uppercase text-sm">
                  <UploadCloud className="w-4 h-4 shrink-0 text-amber-400" />
                  <span>Vercel Ke Liye Ready ZIP Code Bundle Tayar Hai!</span>
                </div>
                <p className="text-xs text-neutral-300 font-mono leading-relaxed">
                  Is ZIP file me tournament app ka mukammal source code aur Vercel configuration (<code className="text-amber-300">vercel.json</code>) shamil hai. Vercel par host karne se aapko apna <strong>Free Permanent .vercel.app Link</strong> mil jayega jo kisi bhi player ke phone me bina kisi error ke 24/7 chalega!
                </p>
              </div>

              {/* Direct 1-Click Download Button */}
              <a
                href="/freefire-tournament-vercel.zip"
                download="freefire-tournament-vercel.zip"
                className="w-full p-4 rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 text-neutral-950 font-bold flex items-center justify-center gap-3 text-sm font-display uppercase tracking-wider shadow-xl shadow-amber-500/20 transition-all cursor-pointer group"
              >
                <Download className="w-5 h-5 text-neutral-950 group-hover:scale-110 transition-transform" />
                <span>Download Vercel ZIP Code (4.6 MB)</span>
              </a>

              {/* Step by Step Guide in Roman Urdu */}
              <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 space-y-3 font-mono text-xs">
                <div className="text-amber-400 font-bold uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>Vercel Par Upload & Live Karne Ka Tariqa:</span>
                </div>

                <div className="space-y-2.5 text-neutral-300 text-[11px]">
                  <div className="p-3 rounded-lg bg-neutral-900/90 border border-neutral-800 space-y-1">
                    <strong className="text-white block font-bold">
                      Step 1: Upar wala button daba kar ZIP download karein
                    </strong>
                    <p className="text-neutral-400">
                      ZIP file aapke mobile ya computer ke Downloads folder me save ho jayegi.
                    </p>
                  </div>

                  <div className="p-3 rounded-lg bg-neutral-900/90 border border-neutral-800 space-y-1">
                    <strong className="text-white block font-bold">
                      Step 2: Vercel.com par Free Account banayein
                    </strong>
                    <p className="text-neutral-400">
                      Browser me <span className="text-amber-400">vercel.com</span> kholein aur Google/GitHub se free sign up karein.
                    </p>
                  </div>

                  <div className="p-3 rounded-lg bg-neutral-900/90 border border-neutral-800 space-y-1">
                    <strong className="text-white block font-bold">
                      Step 3: GitHub par Upload karein ya Vercel CLI use karein
                    </strong>
                    <p className="text-neutral-400">
                      - ZIP ko extract karein.<br />
                      - GitHub par new repository (e.g. <code>ff-tournament</code>) bana kar files upload kar dein.<br />
                      - Vercel me <strong>"Import Project"</strong> dabayein.<br />
                      - Framework Preset: <strong>Vite</strong><br />
                      - Build Command: <code>npm run build</code><br />
                      - Output Directory: <code>dist</code>
                    </p>
                  </div>

                  <div className="p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 space-y-1">
                    <strong className="block font-bold">
                      🎉 Mubarak! 1 Minute Me Link Active:
                    </strong>
                    <p className="text-neutral-300">
                      Aapko <code>https://ff-tournament.vercel.app</code> jaisa permanent link mil jayega jo 100% free hai aur sabhi players ke paas smoothly chalega!
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB: ERROR DIAGNOSTICS & EXACT SOLUTION */}
          {activeTab === 'fix_error' && (
            <div className="space-y-4">
              {/* Error Explanation Card */}
              <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/30 space-y-2">
                <div className="flex items-center gap-2 text-red-400 font-bold font-display uppercase text-sm">
                  <AlertTriangle className="w-4 h-4 shrink-0 text-red-400" />
                  <span>Player ko "404 Page Not Found" ya "Login Error" kyu aa raha hai?</span>
                </div>
                <p className="text-xs text-neutral-300 font-mono leading-relaxed">
                  Google AI Studio me jab tak aap upar <strong>"Share"</strong> button nahi dabate, link internet par publish nahi hota aur players ko <strong>404 error</strong> show hota hai.
                </p>
              </div>

              {/* Step by Step Solution */}
              <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 space-y-3 font-mono text-xs text-neutral-300">
                <div className="text-amber-400 font-bold uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>Link Ko Public Karne Ke 2 Aasan Tarike:</span>
                </div>

                <div className="p-3 rounded-lg bg-neutral-900 border border-neutral-800 space-y-2">
                  <strong className="text-white block font-bold text-xs">
                    Tariqa #1: AI Studio me "Share" Button Dabayein
                  </strong>
                  <p className="text-neutral-300 text-[11px]">
                    1. AI Studio screen ke upar right corner me <strong>"Share"</strong> button par click karein.
                  </p>
                  <p className="text-neutral-300 text-[11px]">
                    2. Google wahan se aapko public link de dega jo kisi bhi player ke paas bina kisi error ke khul jayega!
                  </p>
                </div>

                <div className="p-3 rounded-lg bg-neutral-900 border border-neutral-800 space-y-2">
                  <strong className="text-emerald-400 block font-bold text-xs">
                    Tariqa #2: Direct WhatsApp Roster (Sab Se Kamyab Hal)
                  </strong>
                  <p className="text-neutral-300 text-[11px]">
                    Free Fire tournaments me 90% players website ke bajaye direct WhatsApp par squad details bhejte hain.
                  </p>
                  <p className="text-neutral-300 text-[11px]">
                    Neeche <strong>"Direct WhatsApp Roster"</strong> button dabayein. Player ko link kholne ki zaroorat hi nahi paregi, woh WhatsApp par roster bhejega aur aap <strong>"Slots"</strong> tab me add kar lenge!
                  </p>
                </div>
              </div>

              {/* Fast Action Buttons */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                <button
                  onClick={() => setActiveTab('whatsapp_form')}
                  className="p-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold flex items-center justify-center gap-2 text-xs font-display uppercase tracking-wider shadow-lg transition-all"
                >
                  <MessageSquare className="w-4 h-4 text-white" />
                  <span>WhatsApp Roster Form Kholein</span>
                </button>

                <button
                  onClick={() => setActiveTab('links')}
                  className="p-3 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-amber-400 font-bold flex items-center justify-center gap-2 text-xs font-display uppercase tracking-wider border border-neutral-700 transition-all font-mono"
                >
                  <Globe className="w-4 h-4" />
                  <span>Web Links Dekhein</span>
                </button>
              </div>
            </div>
          )}

          {/* TAB 2: OFFLINE WHATSAPP ROSTER (100% RELIABLE) */}
          {activeTab === 'whatsapp_form' && (
            <div className="space-y-4">
              <div className="p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 space-y-1.5">
                <div className="flex items-center gap-2 text-emerald-300 font-bold font-display text-sm uppercase">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>Zero-Error WhatsApp Roster Format</span>
                </div>
                <p className="text-xs text-neutral-300 font-mono">
                  Is message ko WhatsApp groups me share karein. Captains fill kar ke direct aapke WhatsApp number ({tournament.organizerContact}) par bhejenge!
                </p>
              </div>

              {/* 1-Tap Share to WhatsApp */}
              <a
                href={whatsappOfflineShareUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full p-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold flex items-center justify-center gap-2.5 text-sm font-display uppercase tracking-wider shadow-lg transition-all"
              >
                <Send className="w-4 h-4 text-white" />
                <span>WhatsApp Groups Me Roster Form Bhejein</span>
              </a>

              {/* Copyable Form Box */}
              <div className="p-3.5 rounded-xl bg-neutral-950 border border-neutral-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-bold text-neutral-300 uppercase">
                    Roster Text Preview:
                  </span>
                  <button
                    onClick={handleCopyOffline}
                    className="px-3 py-1 text-xs font-bold bg-emerald-600/20 text-emerald-300 hover:bg-emerald-600/30 border border-emerald-500/30 rounded flex items-center gap-1 font-mono"
                  >
                    {copiedOfflineTemplate ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedOfflineTemplate ? 'Copied Form!' : 'Copy Form Text'}</span>
                  </button>
                </div>
                <pre className="p-3 rounded-lg bg-neutral-900 border border-neutral-800 text-[11px] font-mono text-neutral-300 leading-relaxed whitespace-pre-wrap max-h-48 overflow-y-auto">
                  {offlineWhatsAppForm}
                </pre>
              </div>
            </div>
          )}

          {/* TAB 3: ONLINE WEB LINKS */}
          {activeTab === 'links' && (
            <div className="space-y-4">
              {/* Admin Security Assurance Box */}
              <div className="p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-start gap-3">
                <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                <div className="text-xs text-neutral-300">
                  <strong className="text-emerald-300 font-mono block mb-0.5">
                    Aapka Admin Control 100% Mehfooz Hai:
                  </strong>
                  <span>
                    Jab bhi koi player yeh link kholega, uske paas sirf "Player View" open hoga. Score edit karne ke liye aapka secret Admin PIN (7860) darkaar hoga jo sirf aapke paas hai.
                  </span>
                </div>
              </div>

              {/* Custom Link / Shortlink Input */}
              <div className="p-3.5 rounded-xl bg-neutral-950 border border-neutral-800 space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-bold text-neutral-300 uppercase">
                    App Link (Apna Shortlink ya Domain Set Karein):
                  </span>
                  <button
                    onClick={() => setCustomBaseUrl(defaultBaseUrl)}
                    className="text-[10px] text-amber-400 hover:underline font-mono"
                  >
                    Reset Link
                  </button>
                </div>
                <input
                  type="text"
                  value={customBaseUrl}
                  onChange={(e) => setCustomBaseUrl(e.target.value)}
                  placeholder="https://your-public-link.com"
                  className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-2.5 py-1.5 text-xs text-amber-400 font-mono focus:outline-none focus:border-amber-500"
                />
              </div>

              {/* Direct Registration Link */}
              <div className="p-3.5 rounded-xl bg-neutral-950 border border-neutral-800 space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-bold text-amber-400 uppercase">
                    Direct Squad Registration Link:
                  </span>
                  <span className="text-[10px] font-mono text-neutral-500">Opens form directly</span>
                </div>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    readOnly
                    value={registerUrl}
                    className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-2.5 py-1.5 text-xs text-neutral-300 font-mono truncate select-all"
                  />
                  <button
                    onClick={handleCopyRegister}
                    className="px-3 py-1.5 text-xs font-bold bg-neutral-800 hover:bg-neutral-700 text-amber-400 border border-neutral-700 rounded-lg flex items-center gap-1 shrink-0 font-mono"
                  >
                    {copiedRegister ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedRegister ? 'Copied!' : 'Copy'}</span>
                  </button>
                </div>
              </div>

              {/* Formatted WhatsApp Message Preview */}
              <div className="p-3.5 rounded-xl bg-neutral-950 border border-neutral-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-bold text-neutral-300 uppercase">
                    WhatsApp Invite Message:
                  </span>
                  <button
                    onClick={handleCopyMessage}
                    className="px-3 py-1 text-xs font-bold bg-emerald-600/20 text-emerald-300 hover:bg-emerald-600/30 border border-emerald-500/30 rounded flex items-center gap-1 font-mono"
                  >
                    {copiedMessage ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedMessage ? 'Copied!' : 'Copy Text'}</span>
                  </button>
                </div>
                <pre className="p-3 rounded-lg bg-neutral-900 border border-neutral-800 text-[11px] font-mono text-neutral-300 leading-relaxed whitespace-pre-wrap max-h-36 overflow-y-auto">
                  {inviteMessage}
                </pre>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-neutral-950/80 border-t border-neutral-800 flex items-center justify-between text-xs text-neutral-400 font-mono">
          <span>Organizer: {tournament.organizerContact}</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-white font-semibold transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
