import React, { useState } from 'react';
import { Tournament, OverallTeamStanding } from '../types/tournament';
import { generateWhatsAppPointsTable, generateWhatsAppSlotList } from '../utils/scoring';
import { Share2, X, Copy, Check, MessageSquare, FileText, CheckCircle2 } from 'lucide-react';

interface ShareExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  tournament: Tournament;
  standings: OverallTeamStanding[];
  lang: 'en' | 'ur';
}

export const ShareExportModal: React.FC<ShareExportModalProps> = ({
  isOpen,
  onClose,
  tournament,
  standings,
  lang,
}) => {
  const [tab, setTab] = useState<'standings' | 'slots'>('standings');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const currentText =
    tab === 'standings'
      ? generateWhatsAppPointsTable(tournament, standings)
      : generateWhatsAppSlotList(tournament);

  const handleCopy = () => {
    navigator.clipboard.writeText(currentText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-neutral-950/85 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-xl max-h-[90vh] flex flex-col bg-neutral-900 border border-neutral-800 rounded-2xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-800 bg-neutral-950/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <Share2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white font-display uppercase tracking-wide">
                {lang === 'ur' ? 'WhatsApp & Discord Share Export' : 'Share & Export Hub'}
              </h2>
              <p className="text-xs text-neutral-400 font-mono">
                Copy formatted tables for WhatsApp groups & tournament channels
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-neutral-400 hover:text-white p-1.5 rounded-lg hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switcher */}
        <div className="px-6 pt-4 flex items-center justify-between gap-2 border-b border-neutral-800/60 pb-3">
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                setTab('standings');
                setCopied(false);
              }}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-colors font-mono ${
                tab === 'standings'
                  ? 'bg-amber-500 text-neutral-950'
                  : 'bg-neutral-800 text-neutral-300 hover:text-white'
              }`}
            >
              📊 Points Table (WhatsApp)
            </button>
            <button
              onClick={() => {
                setTab('slots');
                setCopied(false);
              }}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-colors font-mono ${
                tab === 'slots'
                  ? 'bg-amber-500 text-neutral-950'
                  : 'bg-neutral-800 text-neutral-300 hover:text-white'
              }`}
            >
              📋 Slot List (WhatsApp)
            </button>
          </div>

          <button
            onClick={handleCopy}
            className="px-4 py-1.5 text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg flex items-center gap-1.5 transition-all font-mono"
          >
            {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            <span>{copied ? 'Copied!' : 'Copy Text'}</span>
          </button>
        </div>

        {/* Formatted Text Preview */}
        <div className="flex-1 overflow-y-auto p-6">
          <div className="relative">
            <pre className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 font-mono text-xs text-emerald-400/95 leading-relaxed overflow-x-auto whitespace-pre font-mono-numbers select-all">
              {currentText}
            </pre>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-neutral-950/70 border-t border-neutral-800 flex items-center justify-between text-xs text-neutral-400 font-mono">
          <span>Formatted with WhatsApp bold (*text*) & emoji styling</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-white font-semibold transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
