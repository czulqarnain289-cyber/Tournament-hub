import React, { useState } from 'react';
import { Tournament } from '../types/tournament';
import { Settings, X, Check, KeyRound, RotateCcw, AlertTriangle } from 'lucide-react';

interface TournamentSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  tournament: Tournament;
  onSaveTournament: (updated: Tournament) => void;
  onResetToDemo: () => void;
  onResetToEmpty: () => void;
  lang: 'en' | 'ur';
}

export const TournamentSettingsModal: React.FC<TournamentSettingsModalProps> = ({
  isOpen,
  onClose,
  tournament,
  onSaveTournament,
  onResetToDemo,
  onResetToEmpty,
  lang,
}) => {
  const [title, setTitle] = useState(tournament.title);
  const [season, setSeason] = useState(tournament.seasonOrEdition);
  const [organizerName, setOrganizerName] = useState(tournament.organizerName);
  const [organizerContact, setOrganizerContact] = useState(tournament.organizerContact);
  const [totalPrizePool, setTotalPrizePool] = useState(tournament.totalPrizePool);
  const [firstPlace, setFirstPlace] = useState(tournament.prizes.firstPlace);
  const [secondPlace, setSecondPlace] = useState(tournament.prizes.secondPlace);
  const [thirdPlace, setThirdPlace] = useState(tournament.prizes.thirdPlace);
  const [mvpPrize, setMvpPrize] = useState(tournament.prizes.mvpPrize || '');
  const [adminPin, setAdminPin] = useState(tournament.adminPin || '7860');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    onSaveTournament({
      ...tournament,
      title,
      seasonOrEdition: season,
      organizerName,
      organizerContact,
      totalPrizePool,
      prizes: {
        firstPlace,
        secondPlace,
        thirdPlace,
        mvpPrize: mvpPrize || undefined,
      },
      adminPin: adminPin.trim() || '7860',
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-neutral-950/85 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-2xl max-h-[90vh] flex flex-col bg-neutral-900 border border-neutral-800 rounded-2xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-800 bg-neutral-950/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-500">
              <Settings className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white font-display uppercase tracking-wide">
                {lang === 'ur' ? 'Tournament & Host Settings' : 'Tournament & Host Settings'}
              </h2>
              <p className="text-xs text-neutral-400 font-mono">
                Manage tournament branding, prize pool, and security PIN
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-neutral-400 hover:text-white p-1.5 rounded-lg hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-5">
          {/* Tournament Identity */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-mono text-neutral-300 mb-1">
                Tournament Title
              </label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Free Fire Bermuda Championship"
                className="w-full bg-neutral-950 border border-neutral-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500 font-semibold"
              />
            </div>

            <div>
              <label className="block text-xs font-mono text-neutral-300 mb-1">
                Edition / Season Tag
              </label>
              <input
                type="text"
                value={season}
                onChange={(e) => setSeason(e.target.value)}
                placeholder="e.g. Season 4 Grand Final"
                className="w-full bg-neutral-950 border border-neutral-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500 font-mono"
              />
            </div>
          </div>

          {/* Organizer Info */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-mono text-neutral-300 mb-1">
                Host / Organizer Name
              </label>
              <input
                type="text"
                value={organizerName}
                onChange={(e) => setOrganizerName(e.target.value)}
                placeholder="Your Name / Clan Name"
                className="w-full bg-neutral-950 border border-neutral-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label className="block text-xs font-mono text-neutral-300 mb-1">
                Organizer WhatsApp Contact
              </label>
              <input
                type="text"
                value={organizerContact}
                onChange={(e) => setOrganizerContact(e.target.value)}
                placeholder="+92 300 1234567"
                className="w-full bg-neutral-950 border border-neutral-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500 font-mono"
              />
            </div>
          </div>

          {/* Prizes Breakdown */}
          <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 space-y-3">
            <h3 className="text-xs font-mono font-bold text-amber-400 uppercase tracking-wider">
              Prize Pool & Distribution
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-mono text-neutral-400 mb-1">
                  Total Prize Pool
                </label>
                <input
                  type="text"
                  value={totalPrizePool}
                  onChange={(e) => setTotalPrizePool(e.target.value)}
                  placeholder="e.g. PKR 25,000 / 10,000 Diamonds"
                  className="w-full bg-neutral-900 border border-neutral-700 rounded px-2.5 py-1.5 text-xs text-amber-400 font-bold focus:outline-none focus:border-amber-500 font-mono"
                />
              </div>
              <div>
                <label className="block text-[11px] font-mono text-neutral-400 mb-1">
                  1st Place (Champion) Prize
                </label>
                <input
                  type="text"
                  value={firstPlace}
                  onChange={(e) => setFirstPlace(e.target.value)}
                  placeholder="PKR 14,000 + Trophy"
                  className="w-full bg-neutral-900 border border-neutral-700 rounded px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-amber-500"
                />
              </div>
              <div>
                <label className="block text-[11px] font-mono text-neutral-400 mb-1">
                  2nd Place Prize
                </label>
                <input
                  type="text"
                  value={secondPlace}
                  onChange={(e) => setSecondPlace(e.target.value)}
                  placeholder="PKR 7,000"
                  className="w-full bg-neutral-900 border border-neutral-700 rounded px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-amber-500"
                />
              </div>
              <div>
                <label className="block text-[11px] font-mono text-neutral-400 mb-1">
                  3rd Place Prize
                </label>
                <input
                  type="text"
                  value={thirdPlace}
                  onChange={(e) => setThirdPlace(e.target.value)}
                  placeholder="PKR 3,000"
                  className="w-full bg-neutral-900 border border-neutral-700 rounded px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-amber-500"
                />
              </div>
            </div>
          </div>

          {/* Security PIN */}
          <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 flex items-center justify-between gap-4">
            <div>
              <div className="text-xs font-mono font-bold text-neutral-200 uppercase tracking-wider flex items-center gap-1.5">
                <KeyRound className="w-4 h-4 text-amber-500" />
                <span>Admin Lock PIN</span>
              </div>
              <p className="text-[11px] text-neutral-400 mt-0.5">
                Used to unlock host management mode (Default is 7860)
              </p>
            </div>
            <input
              type="text"
              maxLength={8}
              value={adminPin}
              onChange={(e) => setAdminPin(e.target.value)}
              className="w-28 bg-neutral-900 border border-neutral-700 rounded px-3 py-1.5 text-center text-sm font-mono font-bold text-amber-400 focus:outline-none focus:border-amber-500"
            />
          </div>

          {/* Reset / Backup helpers */}
          <div className="p-4 rounded-xl border border-red-500/20 bg-red-500/5 space-y-3">
            <div className="flex items-center gap-2 text-xs font-mono font-bold text-red-400 uppercase">
              <AlertTriangle className="w-4 h-4" />
              <span>Reset & Tournament Data Options</span>
            </div>
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => {
                  if (confirm('Load prefilled demo tournament data with 12 squads and 2 matches?')) {
                    onResetToDemo();
                    onClose();
                  }
                }}
                className="px-3 py-1.5 text-xs font-semibold bg-neutral-800 hover:bg-neutral-700 text-neutral-200 border border-neutral-700 rounded font-mono"
              >
                Reload Demo Tournament
              </button>
              <button
                type="button"
                onClick={() => {
                  if (confirm('Are you sure you want to start a brand new empty tournament? All matches and slots will be cleared.')) {
                    onResetToEmpty();
                    onClose();
                  }
                }}
                className="px-3 py-1.5 text-xs font-semibold bg-red-500/20 hover:bg-red-500/30 text-red-300 border border-red-500/40 rounded font-mono"
              >
                Clear All & Start New Tourney
              </button>
            </div>
          </div>

          {/* Footer Save Button */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-neutral-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-neutral-400 hover:text-white rounded-lg hover:bg-neutral-800 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2 text-xs font-bold bg-amber-500 hover:bg-amber-400 text-neutral-950 rounded-lg shadow font-display uppercase tracking-wider flex items-center gap-2"
            >
              <Check className="w-4 h-4" />
              <span>Save Tournament Settings</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
