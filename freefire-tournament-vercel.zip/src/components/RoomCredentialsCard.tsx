import React, { useState } from 'react';
import { CustomRoomConfig } from '../types/tournament';
import { KeyRound, Lock, Eye, EyeOff, Copy, Check, ShieldAlert, Clock, Sparkles, CheckCircle2, Edit2, Share2 } from 'lucide-react';

interface RoomCredentialsCardProps {
  roomConfig: CustomRoomConfig;
  tournamentTitle: string;
  isAdmin: boolean;
  onUpdateRoomConfig: (config: CustomRoomConfig) => void;
  lang: 'en' | 'ur';
}

export const RoomCredentialsCard: React.FC<RoomCredentialsCardProps> = ({
  roomConfig,
  tournamentTitle,
  isAdmin,
  onUpdateRoomConfig,
  lang,
}) => {
  const [copiedId, setCopiedId] = useState(false);
  const [copiedPass, setCopiedPass] = useState(false);
  const [copiedAll, setCopiedAll] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editForm, setEditForm] = useState<CustomRoomConfig>({ ...roomConfig });

  const handleCopyId = () => {
    navigator.clipboard.writeText(roomConfig.roomId);
    setCopiedId(true);
    setTimeout(() => setCopiedId(false), 2000);
  };

  const handleCopyPass = () => {
    navigator.clipboard.writeText(roomConfig.roomPassword);
    setCopiedPass(true);
    setTimeout(() => setCopiedPass(false), 2000);
  };

  const handleCopyFullBroadcast = () => {
    const text = `🔥 *${tournamentTitle.toUpperCase()} - CUSTOM ROOM DETAILS* 🔥\n\n` +
      `🆔 *Room ID:* ${roomConfig.roomId}\n` +
      `🔑 *Password:* ${roomConfig.roomPassword}\n` +
      `⏰ *Time:* ${roomConfig.matchTime}\n` +
      `🗺️ *Mode:* ${roomConfig.gameMode}\n` +
      `⚙️ *Settings:* Gun Attributes: ${roomConfig.gunAttributes ? 'YES' : 'NO'} | Skills: ${roomConfig.characterSkill ? 'YES' : 'NO'}\n\n` +
      `⚠️ *IMPORTANT RULES:*\n` +
      `• Sit strictly in your allotted slot number!\n` +
      `• Do not leak credentials to unverified players.\n` +
      `• Match will start on exact time!`;

    navigator.clipboard.writeText(text);
    setCopiedAll(true);
    setTimeout(() => setCopiedAll(false), 2500);
  };

  const handleTogglePublish = () => {
    onUpdateRoomConfig({
      ...roomConfig,
      isPublished: !roomConfig.isPublished,
    });
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateRoomConfig(editForm);
    setIsEditing(false);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner with Admin publish switch */}
      <div className="rounded-2xl border border-neutral-800 bg-gradient-to-br from-neutral-900 to-neutral-950 p-6 shadow-xl relative overflow-hidden">
        {/* Decorative corner glow */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-neutral-800">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-500 shrink-0">
              <KeyRound className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-2xl font-black text-white font-display uppercase tracking-wide">
                  Custom Room ID & Password
                </h2>
                {roomConfig.isPublished ? (
                  <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-bold border border-emerald-500/30">
                    LIVE (PUBLISHED)
                  </span>
                ) : (
                  <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-amber-500/20 text-amber-400 font-bold border border-amber-500/30">
                    ADMIN HIDDEN
                  </span>
                )}
              </div>
              <p className="text-xs text-neutral-400 font-mono mt-0.5">
                Match Schedule: <strong className="text-neutral-200">{roomConfig.matchDate} at {roomConfig.matchTime}</strong>
              </p>
            </div>
          </div>

          {/* Admin Controls */}
          {isAdmin && (
            <div className="flex items-center gap-2">
              <button
                onClick={handleTogglePublish}
                className={`px-3 py-1.5 text-xs font-bold rounded-lg border flex items-center gap-1.5 transition-all font-mono ${
                  roomConfig.isPublished
                    ? 'bg-neutral-800 border-neutral-700 text-neutral-300 hover:text-white'
                    : 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300 hover:bg-emerald-500/30'
                }`}
              >
                {roomConfig.isPublished ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                <span>{roomConfig.isPublished ? 'Hide from Players' : 'Publish to Players'}</span>
              </button>

              <button
                onClick={() => {
                  setEditForm({ ...roomConfig });
                  setIsEditing(true);
                }}
                className="px-3 py-1.5 text-xs font-semibold bg-neutral-800 hover:bg-neutral-700 text-neutral-200 border border-neutral-700 rounded-lg flex items-center gap-1.5 transition-colors"
              >
                <Edit2 className="w-3.5 h-3.5 text-amber-400" />
                <span>Edit Credentials</span>
              </button>
            </div>
          )}
        </div>

        {/* Credentials Display Box */}
        {roomConfig.isPublished || isAdmin ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 my-6">
            {/* Room ID Box */}
            <div className="p-5 rounded-xl bg-neutral-950 border border-neutral-800 flex items-center justify-between">
              <div>
                <span className="text-[11px] font-mono text-neutral-400 uppercase tracking-wider block">
                  Custom Room ID
                </span>
                <span className="text-2xl sm:text-3xl font-extrabold text-amber-400 font-mono tracking-wider">
                  {roomConfig.roomId || 'NOT SET'}
                </span>
              </div>
              <button
                onClick={handleCopyId}
                disabled={!roomConfig.roomId}
                className="px-4 py-2.5 bg-neutral-900 hover:bg-neutral-800 border border-neutral-700 hover:border-amber-500/50 text-neutral-200 hover:text-white rounded-lg flex items-center gap-2 text-xs font-mono font-bold transition-all shadow-sm"
              >
                {copiedId ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4 text-amber-400" />}
                <span>{copiedId ? 'COPIED!' : 'COPY ID'}</span>
              </button>
            </div>

            {/* Room Password Box */}
            <div className="p-5 rounded-xl bg-neutral-950 border border-neutral-800 flex items-center justify-between">
              <div>
                <span className="text-[11px] font-mono text-neutral-400 uppercase tracking-wider block">
                  Room Password
                </span>
                <span className="text-2xl sm:text-3xl font-extrabold text-white font-mono tracking-wider">
                  {roomConfig.roomPassword || 'NOT SET'}
                </span>
              </div>
              <button
                onClick={handleCopyPass}
                disabled={!roomConfig.roomPassword}
                className="px-4 py-2.5 bg-neutral-900 hover:bg-neutral-800 border border-neutral-700 hover:border-amber-500/50 text-neutral-200 hover:text-white rounded-lg flex items-center gap-2 text-xs font-mono font-bold transition-all shadow-sm"
              >
                {copiedPass ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4 text-amber-400" />}
                <span>{copiedPass ? 'COPIED!' : 'COPY PASS'}</span>
              </button>
            </div>
          </div>
        ) : (
          <div className="my-8 p-8 rounded-xl bg-neutral-950/70 border border-neutral-800 text-center">
            <Lock className="w-8 h-8 text-amber-500/80 mx-auto mb-2" />
            <h3 className="text-lg font-bold text-white font-display uppercase tracking-wide">
              Room Credentials are Locked
            </h3>
            <p className="text-xs text-neutral-400 max-w-md mx-auto mt-1 font-mono">
              Match shuru hone se 15 minute pehle host Room ID aur Password yahan live publish karega.
            </p>
          </div>
        )}

        {/* Copy broadcast message for WhatsApp */}
        {(roomConfig.isPublished || isAdmin) && (
          <div className="flex items-center justify-between gap-4 pt-4 border-t border-neutral-800/80">
            <div className="text-xs text-neutral-400 font-mono">
              ⚡ Share full formatted Room ID & rules to squad WhatsApp group in 1 tap:
            </div>
            <button
              onClick={handleCopyFullBroadcast}
              className="px-4 py-2 text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg flex items-center gap-2 transition-colors font-mono"
            >
              {copiedAll ? <Check className="w-4 h-4" /> : <Share2 className="w-4 h-4" />}
              <span>{copiedAll ? 'COPIED TO CLIPBOARD!' : 'COPY BROADCAST MESSAGE'}</span>
            </button>
          </div>
        )}
      </div>

      {/* Official Custom Room Settings Checklist */}
      <div className="rounded-xl border border-neutral-800 bg-neutral-900/90 p-5 shadow-lg">
        <h3 className="text-base font-bold text-white font-display uppercase tracking-wider mb-3 flex items-center gap-2">
          <span>⚙️</span>
          <span>Official Custom Room Match Settings</span>
        </h3>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          <div className="p-3 rounded-lg bg-neutral-950 border border-neutral-800 text-center">
            <div className="text-[10px] text-neutral-400 font-mono uppercase">Gun Attributes</div>
            <div className="text-sm font-bold text-red-400 font-mono mt-0.5">
              {roomConfig.gunAttributes ? 'YES' : 'NO (Esports)'}
            </div>
          </div>

          <div className="p-3 rounded-lg bg-neutral-950 border border-neutral-800 text-center">
            <div className="text-[10px] text-neutral-400 font-mono uppercase">Character Skill</div>
            <div className="text-sm font-bold text-emerald-400 font-mono mt-0.5">
              {roomConfig.characterSkill ? 'YES (Active)' : 'NO'}
            </div>
          </div>

          <div className="p-3 rounded-lg bg-neutral-950 border border-neutral-800 text-center">
            <div className="text-[10px] text-neutral-400 font-mono uppercase">Limited Ammo</div>
            <div className="text-sm font-bold text-emerald-400 font-mono mt-0.5">
              {roomConfig.limitedAmmo ? 'YES' : 'NO (Unlimited)'}
            </div>
          </div>

          <div className="p-3 rounded-lg bg-neutral-950 border border-neutral-800 text-center">
            <div className="text-[10px] text-neutral-400 font-mono uppercase">Fall Damage</div>
            <div className="text-sm font-bold text-neutral-200 font-mono mt-0.5">
              {roomConfig.fallDamage ? 'YES' : 'NO'}
            </div>
          </div>

          <div className="p-3 rounded-lg bg-neutral-950 border border-neutral-800 text-center">
            <div className="text-[10px] text-neutral-400 font-mono uppercase">Airdrop</div>
            <div className="text-sm font-bold text-neutral-200 font-mono mt-0.5">
              {roomConfig.airdrop ? 'YES' : 'NO'}
            </div>
          </div>

          <div className="p-3 rounded-lg bg-neutral-950 border border-neutral-800 text-center">
            <div className="text-[10px] text-neutral-400 font-mono uppercase">Server Region</div>
            <div className="text-sm font-bold text-amber-400 font-mono mt-0.5 truncate">
              {roomConfig.serverRegion || 'South Asia'}
            </div>
          </div>
        </div>

        {/* Special Instructions */}
        {roomConfig.instructions && (
          <div className="mt-4 p-3 rounded-lg bg-amber-500/10 border border-amber-500/20 text-xs text-amber-300 font-mono flex items-start gap-2">
            <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <strong className="text-amber-200">Host Notice: </strong>
              <span>{roomConfig.instructions}</span>
            </div>
          </div>
        )}
      </div>

      {/* EDIT CREDENTIALS MODAL (Admin) */}
      {isEditing && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-950/80 backdrop-blur-sm animate-fade-in">
          <div className="relative w-full max-w-lg bg-neutral-900 border border-neutral-800 rounded-xl p-6 shadow-2xl">
            <h3 className="text-xl font-bold text-white font-display uppercase tracking-wide mb-1">
              {lang === 'ur' ? 'Custom Room Details Edit Karein' : 'Edit Custom Room Settings'}
            </h3>
            <p className="text-xs text-neutral-400 mb-4 font-mono">
              Update room ID, password, date & competitive presets
            </p>

            <form onSubmit={handleSaveEdit} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-mono text-neutral-300 mb-1">Room ID</label>
                  <input
                    type="text"
                    required
                    value={editForm.roomId}
                    onChange={(e) => setEditForm({ ...editForm, roomId: e.target.value })}
                    placeholder="e.g. 84920194"
                    className="w-full bg-neutral-950 border border-neutral-700 rounded-lg px-3 py-2 text-sm font-mono text-amber-400 focus:outline-none focus:border-amber-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-mono text-neutral-300 mb-1">Room Password</label>
                  <input
                    type="text"
                    required
                    value={editForm.roomPassword}
                    onChange={(e) => setEditForm({ ...editForm, roomPassword: e.target.value })}
                    placeholder="e.g. ff786"
                    className="w-full bg-neutral-950 border border-neutral-700 rounded-lg px-3 py-2 text-sm font-mono text-white focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-mono text-neutral-300 mb-1">Match Date</label>
                  <input
                    type="date"
                    value={editForm.matchDate}
                    onChange={(e) => setEditForm({ ...editForm, matchDate: e.target.value })}
                    className="w-full bg-neutral-950 border border-neutral-700 rounded-lg px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-amber-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-mono text-neutral-300 mb-1">Match Time</label>
                  <input
                    type="text"
                    value={editForm.matchTime}
                    onChange={(e) => setEditForm({ ...editForm, matchTime: e.target.value })}
                    placeholder="e.g. 08:30 PM PKT"
                    className="w-full bg-neutral-950 border border-neutral-700 rounded-lg px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              {/* Toggles */}
              <div className="grid grid-cols-2 gap-3 pt-2 text-xs font-mono">
                <label className="flex items-center gap-2 cursor-pointer p-2 bg-neutral-950 rounded border border-neutral-800">
                  <input
                    type="checkbox"
                    checked={editForm.gunAttributes}
                    onChange={(e) => setEditForm({ ...editForm, gunAttributes: e.target.checked })}
                    className="rounded border-neutral-700 text-amber-500 focus:ring-0"
                  />
                  <span>Gun Attributes (No = Esports)</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer p-2 bg-neutral-950 rounded border border-neutral-800">
                  <input
                    type="checkbox"
                    checked={editForm.characterSkill}
                    onChange={(e) => setEditForm({ ...editForm, characterSkill: e.target.checked })}
                    className="rounded border-neutral-700 text-amber-500 focus:ring-0"
                  />
                  <span>Character Skills (Active)</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer p-2 bg-neutral-950 rounded border border-neutral-800">
                  <input
                    type="checkbox"
                    checked={editForm.limitedAmmo}
                    onChange={(e) => setEditForm({ ...editForm, limitedAmmo: e.target.checked })}
                    className="rounded border-neutral-700 text-amber-500 focus:ring-0"
                  />
                  <span>Limited Ammo (Yes)</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer p-2 bg-neutral-950 rounded border border-neutral-800">
                  <input
                    type="checkbox"
                    checked={editForm.isPublished}
                    onChange={(e) => setEditForm({ ...editForm, isPublished: e.target.checked })}
                    className="rounded border-neutral-700 text-amber-500 focus:ring-0"
                  />
                  <span className="text-amber-400 font-bold">Publish to Players</span>
                </label>
              </div>

              <div>
                <label className="block text-xs font-mono text-neutral-300 mb-1">Host Instructions</label>
                <textarea
                  rows={2}
                  value={editForm.instructions}
                  onChange={(e) => setEditForm({ ...editForm, instructions: e.target.value })}
                  placeholder="Slot rules, emulator bans, or kick warnings..."
                  className="w-full bg-neutral-950 border border-neutral-700 rounded-lg p-2.5 text-xs text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-neutral-800">
                <button
                  type="button"
                  onClick={() => setIsEditing(false)}
                  className="px-4 py-2 text-xs font-semibold text-neutral-400 hover:text-white rounded-lg hover:bg-neutral-800 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold bg-amber-500 hover:bg-amber-400 text-neutral-950 rounded-lg shadow font-display uppercase tracking-wider"
                >
                  Save Credentials
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
