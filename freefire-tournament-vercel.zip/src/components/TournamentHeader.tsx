import React from 'react';
import { Tournament, OverallTeamStanding } from '../types/tournament';
import { Trophy, Share2, PlusCircle, Settings, Users, Calendar, Award, Smartphone } from 'lucide-react';

interface TournamentHeaderProps {
  tournament: Tournament;
  standings: OverallTeamStanding[];
  isAdmin: boolean;
  onOpenSettings: () => void;
  onOpenNewMatch: () => void;
  onOpenShare: () => void;
  onOpenInstallModal: () => void;
  onOpenInviteModal: () => void;
  lang: 'en' | 'ur';
}

export const TournamentHeader: React.FC<TournamentHeaderProps> = ({
  tournament,
  standings,
  isAdmin,
  onOpenSettings,
  onOpenNewMatch,
  onOpenShare,
  onOpenInstallModal,
  onOpenInviteModal,
  lang,
}) => {
  const completedMatches = tournament.matches.filter((m) => m.isCompleted).length;
  const filledSlots = tournament.slots.filter((s) => s.teamName && s.teamName.trim() !== '').length;
  const currentLeader = standings.length > 0 ? standings[0] : null;

  return (
    <div className="relative mb-8 overflow-hidden rounded-2xl border border-neutral-800 bg-neutral-900 shadow-xl">
      {/* Background Hero Banner with High Contrast Scrim */}
      <div className="relative h-48 sm:h-64 w-full overflow-hidden bg-neutral-950">
        <img
          src="/src/assets/images/freefire_esports_banner_1792784698233.jpg"
          alt="Free Fire Tournament Arena"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-center opacity-45 scale-105 transform hover:scale-100 transition-transform duration-700"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-neutral-950 via-neutral-950/60 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-r from-neutral-950/90 via-transparent to-neutral-950/70" />

        {/* Floating Tournament Badges */}
        <div className="absolute top-4 left-4 right-4 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2 text-xs font-semibold">
            <span className="px-2.5 py-1 bg-amber-500 text-neutral-950 font-bold uppercase tracking-wider rounded font-mono text-[11px]">
              {tournament.format}
            </span>
            <span className="hidden sm:inline-block px-2 py-0.5 bg-neutral-900/80 backdrop-blur border border-neutral-700 text-neutral-300 rounded font-mono text-[11px]">
              {tournament.seasonOrEdition}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onOpenInviteModal}
              className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-lg flex items-center gap-1.5 transition-all shadow-md font-mono"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>Players Invite Link</span>
            </button>
            <button
              onClick={onOpenInstallModal}
              className="hidden sm:flex px-3 py-1.5 bg-amber-500/20 hover:bg-amber-500/30 backdrop-blur border border-amber-500/40 text-amber-300 text-xs font-semibold rounded-lg items-center gap-1.5 transition-colors shadow-sm font-mono"
            >
              <Smartphone className="w-3.5 h-3.5 text-amber-400" />
              <span>App Install</span>
            </button>
            <button
              onClick={onOpenShare}
              className="hidden md:flex px-3 py-1.5 bg-neutral-900/85 hover:bg-neutral-800 backdrop-blur border border-neutral-700 hover:border-amber-500/50 text-neutral-200 text-xs font-semibold rounded-lg items-center gap-1.5 transition-colors shadow-sm"
            >
              <Share2 className="w-3.5 h-3.5 text-amber-400" />
              <span>WhatsApp Table</span>
            </button>
            {isAdmin && (
              <button
                onClick={onOpenSettings}
                className="px-3 py-1.5 bg-neutral-900/85 hover:bg-neutral-800 backdrop-blur border border-neutral-700 hover:border-amber-500/50 text-neutral-200 text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors shadow-sm"
              >
                <Settings className="w-3.5 h-3.5 text-neutral-400" />
                <span className="hidden sm:inline">Settings</span>
              </button>
            )}
          </div>
        </div>

        {/* Title and Organizer lockup inside banner */}
        <div className="absolute bottom-4 left-4 sm:left-6 right-4 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-amber-400 text-xs font-mono font-medium tracking-wide">
              <span>HOST: {tournament.organizerName.toUpperCase()}</span>
              <span>·</span>
              <span>{tournament.roomConfig.matchDate}</span>
            </div>
            <h1 className="text-2xl sm:text-4xl font-extrabold text-white font-display uppercase tracking-wide drop-shadow-md text-balance">
              {tournament.title}
            </h1>
          </div>

          {isAdmin && (
            <button
              onClick={onOpenNewMatch}
              className="self-start sm:self-auto px-4 py-2 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-neutral-950 font-bold rounded-lg text-xs flex items-center gap-2 shadow-lg shadow-orange-500/20 font-display uppercase tracking-wider transition-all"
            >
              <PlusCircle className="w-4 h-4 text-neutral-950" />
              <span>+ Record Match Score</span>
            </button>
          )}
        </div>
      </div>

      {/* 4-Column Quick Stat Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 divide-y sm:divide-y-0 sm:divide-x divide-neutral-800 border-t border-neutral-800 bg-neutral-950/70">
        <div className="p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 shrink-0">
            <Trophy className="w-5 h-5" />
          </div>
          <div>
            <div className="text-[11px] uppercase tracking-wider text-neutral-400 font-medium">
              Total Prize Pool
            </div>
            <div className="text-base sm:text-lg font-extrabold text-amber-400 font-mono-numbers">
              {tournament.totalPrizePool}
            </div>
          </div>
        </div>

        <div className="p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400 shrink-0">
            <Users className="w-5 h-5" />
          </div>
          <div>
            <div className="text-[11px] uppercase tracking-wider text-neutral-400 font-medium">
              Confirmed Slots
            </div>
            <div className="text-base sm:text-lg font-bold text-white font-mono-numbers">
              {filledSlots} <span className="text-xs text-neutral-500 font-normal">/ {tournament.maxSlots}</span>
            </div>
          </div>
        </div>

        <div className="p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 shrink-0">
            <Calendar className="w-5 h-5" />
          </div>
          <div>
            <div className="text-[11px] uppercase tracking-wider text-neutral-400 font-medium">
              Matches Completed
            </div>
            <div className="text-base sm:text-lg font-bold text-white font-mono-numbers">
              {completedMatches} <span className="text-xs text-neutral-500 font-normal">/ {tournament.matches.length} Maps</span>
            </div>
          </div>
        </div>

        <div className="p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-orange-500/10 border border-orange-500/20 flex items-center justify-center text-orange-400 shrink-0">
            <Award className="w-5 h-5" />
          </div>
          <div className="truncate">
            <div className="text-[11px] uppercase tracking-wider text-neutral-400 font-medium">
              #1 Table Leader
            </div>
            <div className="text-base font-bold text-amber-300 truncate">
              {currentLeader ? currentLeader.teamName : 'TBD'}
              {currentLeader && (
                <span className="ml-1.5 text-xs text-neutral-400 font-mono font-normal">
                  ({currentLeader.totalPoints} pts)
                </span>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
