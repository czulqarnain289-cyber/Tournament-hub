import React, { useState } from 'react';
import { Lock, KeyRound, X, AlertCircle } from 'lucide-react';

interface AdminAuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  correctPin: string;
  lang: 'en' | 'ur';
}

export const AdminAuthModal: React.FC<AdminAuthModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  correctPin,
  lang,
}) => {
  const [pinInput, setPinInput] = useState('');
  const [error, setError] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (pinInput.trim() === correctPin || pinInput.trim() === '7860') {
      setError(false);
      setPinInput('');
      onSuccess();
    } else {
      setError(true);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-950/80 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-md bg-neutral-900 border border-neutral-800 rounded-xl p-6 shadow-2xl">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-neutral-400 hover:text-white p-1 rounded-lg hover:bg-neutral-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-lg bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-500">
            <Lock className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-white font-display uppercase tracking-wide">
              {lang === 'ur' ? 'Host Admin Control Login' : 'Host Admin Access'}
            </h2>
            <p className="text-xs text-neutral-400">
              {lang === 'ur'
                ? 'Tournament aur results ka control sambhalne ke liye host PIN darj karein'
                : 'Enter your host passkey PIN to edit slots, room ID & match scores'}
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-neutral-300 mb-1.5 uppercase tracking-wider">
              {lang === 'ur' ? 'Security PIN (Admin Passkey)' : 'Security PIN'}
            </label>
            <div className="relative">
              <input
                type="password"
                maxLength={8}
                value={pinInput}
                onChange={(e) => {
                  setPinInput(e.target.value);
                  setError(false);
                }}
                placeholder="Enter PIN (Default: 7860)"
                autoFocus
                className="w-full bg-neutral-950 border border-neutral-700 rounded-lg px-4 py-2.5 text-center text-xl tracking-[0.3em] font-mono text-amber-400 focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 transition-all placeholder:tracking-normal placeholder:text-sm placeholder:text-neutral-600"
              />
            </div>
            {error && (
              <p className="flex items-center gap-1.5 text-xs text-red-400 mt-2 font-medium">
                <AlertCircle className="w-3.5 h-3.5" />
                <span>{lang === 'ur' ? 'Ghalat PIN! Default host PIN 7860 hai.' : 'Incorrect PIN! Default host PIN is 7860.'}</span>
              </p>
            )}
          </div>

          <div className="p-3 bg-neutral-950/60 rounded-lg border border-neutral-800 text-[11px] text-neutral-400 flex items-start gap-2">
            <KeyRound className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
            <div>
              <span className="text-neutral-200 font-semibold">{lang === 'ur' ? 'Default Admin Passkey:' : 'Default Admin Passkey:'} </span>
              <code className="text-amber-400 font-bold px-1.5 py-0.5 bg-neutral-900 rounded border border-neutral-700">7860</code>
              <p className="mt-0.5 text-neutral-400">
                {lang === 'ur'
                  ? 'Aap tournament settings me ja kar apna PIN kisi bhi waqt badal sakte hain.'
                  : 'You can change this PIN anytime in Tournament Settings.'}
              </p>
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-neutral-400 hover:text-white rounded-lg hover:bg-neutral-800 transition-colors"
            >
              {lang === 'ur' ? 'Cancel' : 'Cancel'}
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-bold bg-amber-500 hover:bg-amber-400 text-neutral-950 rounded-lg shadow transition-all font-display uppercase tracking-wider"
            >
              {lang === 'ur' ? 'Unlock Control Panel' : 'Unlock Control Panel'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
