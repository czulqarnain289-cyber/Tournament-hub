import React, { useState } from 'react';
import { RegistrationRequest, TeamSlot } from '../types/tournament';
import { X, Check, Trash2, Users, Phone, ArrowRight, ShieldAlert } from 'lucide-react';

interface PendingRequestsDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  requests: RegistrationRequest[];
  slots: TeamSlot[];
  onApprove: (requestId: string, slotNumber: number) => void;
  onReject: (requestId: string) => void;
  lang: 'en' | 'ur';
}

export const PendingRequestsDrawer: React.FC<PendingRequestsDrawerProps> = ({
  isOpen,
  onClose,
  requests,
  slots,
  onApprove,
  onReject,
  lang,
}) => {
  const [selectedSlotForReq, setSelectedSlotForReq] = useState<Record<string, number>>({});

  if (!isOpen) return null;

  // Unoccupied slots
  const openSlots = slots.filter((s) => !s.teamName || s.teamName.trim() === '');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-neutral-950/85 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-2xl max-h-[85vh] flex flex-col bg-neutral-900 border border-neutral-800 rounded-2xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-800 bg-neutral-950/70">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-500 font-bold">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white font-display uppercase tracking-wide">
                {lang === 'ur' ? 'Pending Squad Registrations' : 'Pending Squad Registrations'}
              </h2>
              <p className="text-xs text-neutral-400 font-mono">
                {requests.length} teams waiting for host slot approval
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-neutral-400 hover:text-white p-1.5 rounded-lg hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* List of Requests */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {requests.length > 0 ? (
            requests.map((req) => {
              const chosenSlot =
                selectedSlotForReq[req.id] ||
                (openSlots.length > 0 ? openSlots[0].slotNumber : 1);

              return (
                <div
                  key={req.id}
                  className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 space-y-3"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-white text-base font-sans">
                          {req.teamName}
                        </span>
                        <span className="text-[10px] font-mono px-1.5 py-0.5 bg-neutral-800 text-amber-400 rounded">
                          {req.teamTag}
                        </span>
                      </div>
                      <div className="text-xs text-neutral-400 font-mono mt-0.5">
                        Captain: <strong className="text-neutral-200">{req.captainName}</strong> (UID: {req.captainUid}) · {req.submittedAt}
                      </div>
                    </div>

                    <a
                      href={`https://wa.me/${req.captainPhone.replace(/[^0-9]/g, '')}`}
                      target="_blank"
                      rel="noreferrer"
                      className="px-2.5 py-1 text-xs bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/20 rounded font-mono flex items-center gap-1 shrink-0"
                    >
                      <Phone className="w-3 h-3" />
                      <span>{req.captainPhone}</span>
                    </a>
                  </div>

                  {/* Players chips */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px] font-mono">
                    <div className="p-1.5 bg-neutral-900 rounded border border-neutral-800">
                      <div className="text-neutral-200 truncate">{req.player1.ign}</div>
                      <div className="text-neutral-500 text-[10px] truncate">{req.player1.uid}</div>
                    </div>
                    <div className="p-1.5 bg-neutral-900 rounded border border-neutral-800">
                      <div className="text-neutral-200 truncate">{req.player2.ign}</div>
                      <div className="text-neutral-500 text-[10px] truncate">{req.player2.uid}</div>
                    </div>
                    <div className="p-1.5 bg-neutral-900 rounded border border-neutral-800">
                      <div className="text-neutral-200 truncate">{req.player3.ign}</div>
                      <div className="text-neutral-500 text-[10px] truncate">{req.player3.uid}</div>
                    </div>
                    <div className="p-1.5 bg-neutral-900 rounded border border-neutral-800">
                      <div className="text-neutral-200 truncate">{req.player4.ign}</div>
                      <div className="text-neutral-500 text-[10px] truncate">{req.player4.uid}</div>
                    </div>
                  </div>

                  {/* Action Bar */}
                  <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-neutral-800/80">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-mono text-neutral-400">Allot to:</span>
                      <select
                        value={chosenSlot}
                        onChange={(e) =>
                          setSelectedSlotForReq({
                            ...selectedSlotForReq,
                            [req.id]: parseInt(e.target.value, 10),
                          })
                        }
                        className="bg-neutral-900 border border-neutral-700 rounded px-2.5 py-1 text-xs text-amber-400 font-mono font-bold focus:outline-none"
                      >
                        {slots.map((s) => (
                          <option key={s.slotNumber} value={s.slotNumber}>
                            Slot #{s.slotNumber} {s.teamName ? `(Overwrite: ${s.teamName})` : '(Open)'}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => onReject(req.id)}
                        className="px-3 py-1.5 text-xs font-semibold text-red-400 hover:text-red-300 hover:bg-red-500/10 rounded-lg transition-colors font-mono"
                      >
                        Decline
                      </button>
                      <button
                        onClick={() => onApprove(req.id, chosenSlot)}
                        className="px-4 py-1.5 text-xs font-bold bg-amber-500 hover:bg-amber-400 text-neutral-950 rounded-lg shadow font-display uppercase tracking-wider flex items-center gap-1.5"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>Approve & Allot Slot</span>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })
          ) : (
            <div className="py-12 text-center text-neutral-500 font-mono text-xs">
              No pending registrations. New squad sign-ups will show up here.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
