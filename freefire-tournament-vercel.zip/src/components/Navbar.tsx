import React from 'react';
import { Shield, Lock, Unlock, Trophy, Users, KeyRound, PlusCircle, Globe, Settings, Flame, Smartphone, Download, Share2 } from 'lucide-react';

interface NavbarProps {
  activeTab: 'standings' | 'slots' | 'room' | 'register';
  setActiveTab: (tab: 'standings' | 'slots' | 'room' | 'register') => void;
  isAdmin: boolean;
  onOpenAdminLogin: () => void;
  onLockAdmin: () => void;
  onOpenSettings: () => void;
  onOpenNewMatch: () => void;
  onOpenInstallModal: () => void;
  onOpenInviteModal: () => void;
  pendingCount: number;
  onOpenPendingRequests: () => void;
  lang: 'en' | 'ur';
  setLang: (lang: 'en' | 'ur') => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  isAdmin,
  onOpenAdminLogin,
  onLockAdmin,
  onOpenSettings,
  onOpenNewMatch,
  onOpenInstallModal,
  onOpenInviteModal,
  pendingCount,
  onOpenPendingRequests,
  lang,
  setLang,
}) => {
  const t = {
    standings: lang === 'ur' ? 'Results & Points Table' : 'Leaderboard',
    slots: lang === 'ur' ? 'Slots List (1-12)' : 'Slots (1-12)',
    room: lang === 'ur' ? 'Room ID & Pass' : 'Custom Room ID',
    register: lang === 'ur' ? 'Register Squad' : 'Register Squad',
    adminMode: lang === 'ur' ? 'Host Control Active' : 'Admin Mode',
    playerView: lang === 'ur' ? 'Player View' : 'Player View',
    loginAdmin: lang === 'ur' ? 'Admin Login' : 'Admin Login',
    lockAdmin: lang === 'ur' ? 'Lock Admin' : 'Lock Admin',
    newMatch: lang === 'ur' ? '+ Record Match' : '+ Record Match',
    settings: lang === 'ur' ? 'Settings' : 'Settings',
    requests: lang === 'ur' ? 'Requests' : 'Requests',
    installApp: lang === 'ur' ? 'App Install' : 'Install App',
    shareWithPlayers: lang === 'ur' ? 'Share Link (Players)' : 'Share Link',
  };

  return (
    <header className="sticky top-0 z-40 bg-neutral-950/95 backdrop-blur-md border-b border-neutral-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-4 h-16">
          {/* Zone 1: Wordmark / Brand */}
          <div className="flex items-center gap-3 shrink-0">
            <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center shadow-lg shadow-amber-500/20 text-neutral-950 font-black">
              <Flame className="w-5 h-5 text-neutral-950" />
            </div>
            <div>
              <span className="text-xl font-bold tracking-wider text-white font-display uppercase flex items-center gap-2">
                FF TOURNAMENT HUB
              </span>
              <span className="hidden sm:block text-[11px] text-amber-500/90 font-mono tracking-tight -mt-1">
                {isAdmin ? 'HOST CONTROL ACTIVE (FULL ACCESS)' : 'PUBLIC PLAYER RESULTS PORTAL'}
              </span>
            </div>
          </div>

          {/* Zone 2: Navigation Links (single line, functional) */}
          <nav className="hidden md:flex items-center gap-1 text-sm font-medium">
            <button
              onClick={() => setActiveTab('standings')}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-md transition-colors whitespace-nowrap ${
                activeTab === 'standings'
                  ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                  : 'text-neutral-300 hover:text-white hover:bg-neutral-900'
              }`}
            >
              <Trophy className="w-4 h-4 text-amber-500" />
              <span>{t.standings}</span>
            </button>

            <button
              onClick={() => setActiveTab('slots')}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-md transition-colors whitespace-nowrap ${
                activeTab === 'slots'
                  ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                  : 'text-neutral-300 hover:text-white hover:bg-neutral-900'
              }`}
            >
              <Users className="w-4 h-4 text-neutral-400" />
              <span>{t.slots}</span>
            </button>

            <button
              onClick={() => setActiveTab('room')}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-md transition-colors whitespace-nowrap ${
                activeTab === 'room'
                  ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                  : 'text-neutral-300 hover:text-white hover:bg-neutral-900'
              }`}
            >
              <KeyRound className="w-4 h-4 text-neutral-400" />
              <span>{t.room}</span>
            </button>

            <button
              onClick={() => setActiveTab('register')}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-md transition-colors whitespace-nowrap ${
                activeTab === 'register'
                  ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                  : 'text-neutral-300 hover:text-white hover:bg-neutral-900'
              }`}
            >
              <PlusCircle className="w-4 h-4 text-neutral-400" />
              <span>{t.register}</span>
            </button>
          </nav>

          {/* Zone 3: Primary Actions & Admin Control Status */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            {/* Vercel ZIP Download Button */}
            <a
              href="/freefire-tournament-vercel.zip"
              download="freefire-tournament-vercel.zip"
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-lg bg-amber-500 hover:bg-amber-400 text-neutral-950 transition-all font-mono whitespace-nowrap shadow-sm shadow-amber-500/10"
              title="Vercel Par Host Karne Ke Liye ZIP Code Download Karein"
            >
              <Download className="w-3.5 h-3.5 text-neutral-950" />
              <span>Vercel ZIP</span>
            </a>

            {/* Share Link with Players button (prominent) */}
            <button
              onClick={onOpenInviteModal}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white transition-all font-mono whitespace-nowrap shadow-sm"
              title="Share Player & Registration Link"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>{t.shareWithPlayers}</span>
            </button>

            {/* Install App Button */}
            <button
              onClick={onOpenInstallModal}
              className="hidden lg:flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-bold rounded-lg bg-amber-500/15 border border-amber-500/30 text-amber-300 hover:bg-amber-500/25 transition-all font-mono whitespace-nowrap"
              title="Download & Install on Mobile"
            >
              <Smartphone className="w-3.5 h-3.5 text-amber-400" />
              <span>{t.installApp}</span>
            </button>

            {/* Language switch */}
            <button
              onClick={() => setLang(lang === 'en' ? 'ur' : 'en')}
              className="px-2.5 py-1.5 text-xs font-mono font-semibold rounded-md border border-neutral-800 bg-neutral-900 text-neutral-300 hover:text-white hover:border-neutral-700 transition-colors flex items-center gap-1.5"
              title="Toggle English / Roman Urdu"
            >
              <Globe className="w-3.5 h-3.5 text-neutral-400" />
              <span>{lang === 'en' ? 'URDU' : 'ENGLISH'}</span>
            </button>

            {isAdmin ? (
              <div className="flex items-center gap-2">
                {/* Pending requests indicator button */}
                {pendingCount > 0 && (
                  <button
                    onClick={onOpenPendingRequests}
                    className="relative px-2.5 py-1.5 text-xs font-semibold text-amber-300 bg-amber-500/20 border border-amber-500/40 rounded-md hover:bg-amber-500/30 transition-colors flex items-center gap-1"
                  >
                    <span>{t.requests}</span>
                    <span className="w-5 h-5 rounded-full bg-amber-500 text-neutral-950 text-[10px] font-bold flex items-center justify-center">
                      {pendingCount}
                    </span>
                  </button>
                )}

                {/* Add new match score */}
                <button
                  onClick={onOpenNewMatch}
                  className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold bg-amber-500 hover:bg-amber-400 text-neutral-950 rounded-md transition-colors shadow-sm"
                >
                  <PlusCircle className="w-3.5 h-3.5" />
                  <span>{t.newMatch}</span>
                </button>

                {/* Settings button */}
                <button
                  onClick={onOpenSettings}
                  className="p-1.5 text-neutral-400 hover:text-white rounded-md border border-neutral-800 bg-neutral-900 hover:bg-neutral-800 transition-colors"
                  title="Tournament Settings"
                >
                  <Settings className="w-4 h-4" />
                </button>

                {/* Lock Admin */}
                <button
                  onClick={onLockAdmin}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-md bg-emerald-500/15 border border-emerald-500/40 text-emerald-400 hover:bg-emerald-500/25 transition-colors"
                  title="Switch to Player View"
                >
                  <Unlock className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">{t.lockAdmin}</span>
                </button>
              </div>
            ) : (
              <button
                onClick={onOpenAdminLogin}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-md bg-neutral-800 hover:bg-neutral-700 text-neutral-200 border border-neutral-700 transition-colors"
              >
                <Lock className="w-3.5 h-3.5 text-amber-400" />
                <span>{t.loginAdmin}</span>
              </button>
            )}
          </div>
        </div>

        {/* Mobile secondary tab strip */}
        <div className="flex md:hidden items-center justify-between py-2 border-t border-neutral-900 gap-1 overflow-x-auto text-xs">
          <button
            onClick={() => setActiveTab('standings')}
            className={`px-3 py-1 rounded transition-colors whitespace-nowrap ${
              activeTab === 'standings' ? 'bg-amber-500 text-neutral-950 font-bold' : 'text-neutral-400'
            }`}
          >
            {t.standings}
          </button>
          <button
            onClick={() => setActiveTab('slots')}
            className={`px-3 py-1 rounded transition-colors whitespace-nowrap ${
              activeTab === 'slots' ? 'bg-amber-500 text-neutral-950 font-bold' : 'text-neutral-400'
            }`}
          >
            {t.slots}
          </button>
          <button
            onClick={() => setActiveTab('room')}
            className={`px-3 py-1 rounded transition-colors whitespace-nowrap ${
              activeTab === 'room' ? 'bg-amber-500 text-neutral-950 font-bold' : 'text-neutral-400'
            }`}
          >
            {t.room}
          </button>
          <button
            onClick={() => setActiveTab('register')}
            className={`px-3 py-1 rounded transition-colors whitespace-nowrap ${
              activeTab === 'register' ? 'bg-amber-500 text-neutral-950 font-bold' : 'text-neutral-400'
            }`}
          >
            {t.register}
          </button>
          {isAdmin && (
            <button
              onClick={onOpenNewMatch}
              className="px-2 py-1 rounded bg-amber-500/20 text-amber-300 font-bold border border-amber-500/40 whitespace-nowrap"
            >
              {t.newMatch}
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
