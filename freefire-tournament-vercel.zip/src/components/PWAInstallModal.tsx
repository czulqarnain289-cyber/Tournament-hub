import React, { useState } from 'react';
import { Smartphone, Download, Check, Copy, Share, X, QrCode, Sparkles, ExternalLink, HelpCircle, Package, Send } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface PWAInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: 'en' | 'ur';
}

export const PWAInstallModal: React.FC<PWAInstallModalProps> = ({
  isOpen,
  onClose,
  lang,
}) => {
  const { isInstallable, isInstalled, isIOS, isAndroid, install } = usePWAInstall();
  const [copiedLink, setCopiedLink] = useState(false);
  const [activeTab, setActiveTab] = useState<'easy' | 'apk'>('easy');
  const [deviceTab, setDeviceTab] = useState<'android' | 'ios'>(isIOS ? 'ios' : 'android');

  if (!isOpen) return null;

  const publicAppUrl = 'https://ais-pre-q34drs72wmsn35odkhk6he-150327431140.asia-southeast1.run.app';
  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(publicAppUrl)}&color=f59e0b&bgcolor=0a0a0a`;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(publicAppUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  const handleNativeInstall = async () => {
    const success = await install();
    if (success) {
      onClose();
    }
  };

  const whatsappShareUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(
    `🔥 Free Fire Tournament Hub App: ${publicAppUrl}\n(Open in Chrome & tap "Add to Home Screen" to install!)`
  )}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-neutral-950/85 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-xl max-h-[92vh] flex flex-col bg-neutral-900 border border-neutral-800 rounded-2xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-800 bg-neutral-950/70">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center text-neutral-950 shadow-md">
              <Smartphone className="w-5 h-5 text-neutral-950" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white font-display uppercase tracking-wide">
                {lang === 'ur' ? 'Mobile Me Install Ya Download Karein' : 'Install App on Your Mobile'}
              </h2>
              <p className="text-xs text-neutral-400 font-mono">
                {lang === 'ur'
                  ? 'Direct mobile install aur APK download ka asaan hal'
                  : 'Fast direct installation & APK packaging solutions'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-neutral-400 hover:text-white p-1.5 rounded-lg hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switch */}
        <div className="px-6 pt-3 flex items-center gap-2 border-b border-neutral-800 bg-neutral-950/40">
          <button
            onClick={() => setActiveTab('easy')}
            className={`px-3.5 py-2 text-xs font-bold rounded-t-lg transition-colors font-mono flex items-center gap-1.5 border-b-2 ${
              activeTab === 'easy'
                ? 'border-amber-500 text-amber-400 bg-neutral-900'
                : 'border-transparent text-neutral-400 hover:text-white'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>1-Tap Mobile Install (PWA)</span>
          </button>
          <button
            onClick={() => setActiveTab('apk')}
            className={`px-3.5 py-2 text-xs font-bold rounded-t-lg transition-colors font-mono flex items-center gap-1.5 border-b-2 ${
              activeTab === 'apk'
                ? 'border-amber-500 text-amber-400 bg-neutral-900'
                : 'border-transparent text-neutral-400 hover:text-white'
            }`}
          >
            <Package className="w-3.5 h-3.5" />
            <span>Direct APK File (.apk)</span>
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-5">
          {/* Why direct download didn't work notice */}
          <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-start gap-3">
            <HelpCircle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
            <div className="text-xs text-neutral-300">
              <strong className="text-amber-300 font-mono block mb-0.5">
                {lang === 'ur' ? 'Direct download kyu nahi ho raha tha?' : 'Why direct click did not work in preview:'}
              </strong>
              <span>
                {lang === 'ur'
                  ? 'Aap is waqt AI Studio ke preview frame me hain jahan browser security install block karti hai. Neeche diye gaye button se link apne mobile ke Google Chrome me open karein, wahan 1 click me install ho jayega!'
                  : 'You are currently inside the AI Studio sandbox iframe, where browsers block direct install dialogs. Opening the direct standalone link in your phone browser installs it immediately.'}
              </span>
            </div>
          </div>

          {activeTab === 'easy' ? (
            <>
              {/* Action Buttons: Open in Chrome & Send to WhatsApp */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <a
                  href={publicAppUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold flex items-center justify-center gap-2 text-xs font-display uppercase tracking-wider shadow-lg transition-all"
                >
                  <ExternalLink className="w-4 h-4 text-neutral-950" />
                  <span>Open Directly in Chrome</span>
                </a>

                <a
                  href={whatsappShareUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold flex items-center justify-center gap-2 text-xs font-display uppercase tracking-wider shadow-lg transition-all"
                >
                  <Send className="w-4 h-4 text-white" />
                  <span>Send Link to WhatsApp</span>
                </a>
              </div>

              {/* Native Prompt button if supported */}
              {isInstallable && (
                <div className="p-3 rounded-xl bg-neutral-950 border border-neutral-800 flex items-center justify-between">
                  <div className="text-xs font-mono text-neutral-300">
                    Direct installation detected on this device:
                  </div>
                  <button
                    onClick={handleNativeInstall}
                    className="px-3.5 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-amber-400 font-bold text-xs rounded border border-neutral-700 font-mono"
                  >
                    Click to Install
                  </button>
                </div>
              )}

              {/* QR Code and Link Copier */}
              <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 flex flex-col sm:flex-row items-center gap-4">
                <div className="w-28 h-28 rounded-lg bg-neutral-900 border border-neutral-800 p-1.5 shrink-0 flex items-center justify-center">
                  <img
                    src={qrCodeUrl}
                    alt="Scan QR"
                    className="w-full h-full object-contain rounded"
                  />
                </div>
                <div className="space-y-2 text-center sm:text-left flex-1 min-w-0">
                  <div className="text-xs font-mono font-bold text-amber-400 uppercase">
                    Scan with Phone Camera or Copy Link
                  </div>
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      readOnly
                      value={publicAppUrl}
                      className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-2.5 py-1.5 text-[11px] text-neutral-300 font-mono truncate select-all"
                    />
                    <button
                      onClick={handleCopyLink}
                      className="px-3 py-1.5 text-xs font-bold bg-neutral-800 hover:bg-neutral-700 text-amber-400 border border-neutral-700 rounded-lg flex items-center gap-1 shrink-0 font-mono"
                    >
                      {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedLink ? 'Copied' : 'Copy'}</span>
                    </button>
                  </div>
                  <p className="text-[11px] text-neutral-400">
                    Mobile browser me khol kar <strong>"Add to Home screen"</strong> par click karein.
                  </p>
                </div>
              </div>

              {/* Step-by-Step Device Tabs */}
              <div className="space-y-3">
                <div className="flex items-center justify-between pb-1 border-b border-neutral-800">
                  <span className="text-xs font-mono font-bold text-neutral-300 uppercase">
                    Step-by-Step Mobile Instructions:
                  </span>
                  <div className="flex items-center gap-1 bg-neutral-950 p-0.5 rounded-lg border border-neutral-800">
                    <button
                      onClick={() => setDeviceTab('android')}
                      className={`px-2.5 py-1 text-xs font-bold rounded font-mono ${
                        deviceTab === 'android' ? 'bg-amber-500 text-neutral-950' : 'text-neutral-400'
                      }`}
                    >
                      Android
                    </button>
                    <button
                      onClick={() => setDeviceTab('ios')}
                      className={`px-2.5 py-1 text-xs font-bold rounded font-mono ${
                        deviceTab === 'ios' ? 'bg-amber-500 text-neutral-950' : 'text-neutral-400'
                      }`}
                    >
                      iPhone
                    </button>
                  </div>
                </div>

                {deviceTab === 'android' ? (
                  <div className="p-3.5 rounded-xl bg-neutral-950 border border-neutral-800 space-y-2 font-mono text-xs text-neutral-300">
                    <p>1. Apne mobile ke <strong>Google Chrome</strong> me link open karein.</p>
                    <p>2. Upar corner me <strong>3 Dots (⋮)</strong> par tap karein.</p>
                    <p>3. Menu me <strong>"Install app"</strong> ya <strong>"Add to Home screen"</strong> select karein.</p>
                    <p>4. <strong>"Install"</strong> dabayein — Free Fire icon aapke phone ki home screen par aa jayega!</p>
                  </div>
                ) : (
                  <div className="p-3.5 rounded-xl bg-neutral-950 border border-neutral-800 space-y-2 font-mono text-xs text-neutral-300">
                    <p>1. iPhone ke <strong>Safari Browser</strong> me link open karein.</p>
                    <p>2. Neeche <strong>Share button (Arrow icon)</strong> dabayein.</p>
                    <p>3. <strong>"Add to Home Screen" (+)</strong> par tap karein.</p>
                    <p>4. Upar <strong>"Add"</strong> click karein — App home screen par save ho jayegi!</p>
                  </div>
                )}
              </div>
            </>
          ) : (
            /* APK Download Tab */
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 space-y-3">
                <div className="flex items-center gap-2 text-amber-400 font-bold font-display text-base uppercase">
                  <Package className="w-5 h-5 text-amber-500" />
                  <span>Download Standalone Android APK (.apk)</span>
                </div>
                <p className="text-xs text-neutral-300 leading-relaxed font-mono">
                  Agar aapko WhatsApp par share karne ke liye direct <strong>.apk file</strong> chahiye, to Microsoft ke official free tool <strong>PWABuilder</strong> se 1-minute me APK download kar sakte hain:
                </p>

                <div className="p-3 rounded-lg bg-neutral-900 border border-neutral-700/80 space-y-2 text-xs font-mono text-neutral-200">
                  <p><strong>Step 1:</strong> Neeche "Build Android APK" button dabayein.</p>
                  <p><strong>Step 2:</strong> PWABuilder par <strong>"Package for Android"</strong> par click karein.</p>
                  <p><strong>Step 3:</strong> <strong>"Download APK"</strong> par click karein. Signed APK file direct phone me download ho jayegi!</p>
                </div>

                <a
                  href={`https://www.pwabuilder.com/reportcard?site=${encodeURIComponent(publicAppUrl)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full p-3 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-neutral-950 font-bold flex items-center justify-center gap-2 text-xs font-display uppercase tracking-wider shadow-lg transition-all"
                >
                  <Download className="w-4 h-4 text-neutral-950" />
                  <span>Generate & Download APK on PWABuilder</span>
                </a>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-neutral-950/80 border-t border-neutral-800 flex items-center justify-between text-xs text-neutral-400 font-mono">
          <span>Works offline on all Android & iOS devices</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-white font-semibold transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
