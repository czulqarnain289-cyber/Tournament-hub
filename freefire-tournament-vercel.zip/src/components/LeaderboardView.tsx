import React, { useState } from 'react';
import { Tournament, OverallTeamStanding, Match } from '../types/tournament';
import { Trophy, Flame, Target, Share2, Edit3, Trash2, CheckCircle2, Search, ExternalLink } from 'lucide-react';

interface LeaderboardViewProps {
  tournament: Tournament;
  standings: OverallTeamStanding[];
  isAdmin: boolean;
  onEditMatch: (match: Match) => void;
  onDeleteMatch: (matchId: string) => void;
  onOpenNewMatch: () => void;
  onOpenShare: () => void;
  lang: 'en' | 'ur';
}

export const LeaderboardView: React.FC<LeaderboardViewProps> = ({
  tournament,
  standings,
  isAdmin,
  onEditMatch,
  onDeleteMatch,
  onOpenNewMatch,
  onOpenShare,
  lang,
}) => {
  const [selectedTab, setSelectedTab] = useState<'overall' | string>('overall');
  const [searchQuery, setSearchQuery] = useState('');

  // Find top fragger across matches
  const playerKillMap = new Map<string, { ign: string; team: string; kills: number }>();
  tournament.matches.forEach((m) => {
    m.results.forEach((r) => {
      if (r.mvpPlayer && r.mvpKills) {
        const cur = playerKillMap.get(r.mvpPlayer) || { ign: r.mvpPlayer, team: r.teamName, kills: 0 };
        cur.kills += r.mvpKills;
        playerKillMap.set(r.mvpPlayer, cur);
      }
    });
  });
  const topFraggers = Array.from(playerKillMap.values()).sort((a, b) => b.kills - a.kills);
  const bestMvp = topFraggers.length > 0 ? topFraggers[0] : null;

  const filteredStandings = standings.filter((s) =>
    s.teamName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    s.teamTag.toLowerCase().includes(searchQuery.toLowerCase()) ||
    String(s.slotNumber).includes(searchQuery)
  );

  const selectedMatch = tournament.matches.find((m) => m.id === selectedTab);

  return (
    <div className="space-y-6">
      {/* Top Controls: Match Selection Tabs & Share */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pb-2 border-b border-neutral-800">
        {/* Tabs: Overall + Individual matches */}
        <div className="flex items-center gap-1.5 overflow-x-auto p-1 bg-neutral-900 rounded-lg border border-neutral-800">
          <button
            onClick={() => setSelectedTab('overall')}
            className={`px-3.5 py-1.5 text-xs font-bold rounded-md transition-all whitespace-nowrap ${
              selectedTab === 'overall'
                ? 'bg-amber-500 text-neutral-950 shadow-sm'
                : 'text-neutral-400 hover:text-white hover:bg-neutral-800'
            }`}
          >
            🏆 Overall Standings
          </button>

          {tournament.matches.map((m) => (
            <button
              key={m.id}
              onClick={() => setSelectedTab(m.id)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-all whitespace-nowrap flex items-center gap-1.5 ${
                selectedTab === m.id
                  ? 'bg-amber-500 text-neutral-950 font-bold shadow-sm'
                  : 'text-neutral-400 hover:text-white hover:bg-neutral-800'
              }`}
            >
              <span>Match {m.matchNumber} ({m.map})</span>
              {m.isCompleted ? (
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" title="Completed" />
              ) : (
                <span className="w-1.5 h-1.5 rounded-full bg-amber-400/80" title="Scheduled" />
              )}
            </button>
          ))}
        </div>

        {/* Right side actions */}
        <div className="flex items-center gap-2">
          {/* Quick Search */}
          <div className="relative flex-1 sm:w-48">
            <Search className="w-3.5 h-3.5 text-neutral-500 absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search squad..."
              className="w-full bg-neutral-900 border border-neutral-800 rounded-lg pl-8 pr-3 py-1.5 text-xs text-neutral-200 placeholder:text-neutral-600 focus:outline-none focus:border-amber-500"
            />
          </div>

          <button
            onClick={onOpenShare}
            className="px-3 py-1.5 text-xs font-semibold bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded-lg flex items-center gap-1.5 transition-colors whitespace-nowrap"
          >
            <Share2 className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Export Table</span>
          </button>
        </div>
      </div>

      {/* OVERALL STANDINGS VIEW */}
      {selectedTab === 'overall' && (
        <div className="space-y-6">
          {/* Podium / Champion & MVP Showcase (if completed matches exist) */}
          {standings.length >= 3 && tournament.matches.some((m) => m.isCompleted) && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Top Fragger / MVP Card */}
              <div className="relative overflow-hidden rounded-xl bg-gradient-to-br from-neutral-900 to-neutral-950 border border-neutral-800 p-5 flex items-center gap-4 shadow-lg">
                <div className="w-16 h-16 rounded-xl overflow-hidden shrink-0 bg-amber-500/10 border border-amber-500/30 p-1">
                  <img
                    src="/src/assets/images/freefire_championship_trophy_1792784697513.jpg"
                    alt="MVP Trophy"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover rounded-lg"
                  />
                </div>
                <div>
                  <div className="text-[11px] font-mono text-amber-500 font-bold uppercase tracking-wider">
                    TOURNAMENT MVP / TOP FRAGGER
                  </div>
                  <div className="text-lg font-bold text-white font-display">
                    {bestMvp ? bestMvp.ign : 'TBD'}
                  </div>
                  <div className="text-xs text-neutral-400 font-mono">
                    Team: {bestMvp ? bestMvp.team : 'N/A'} · <span className="text-amber-400 font-bold">{bestMvp ? bestMvp.kills : 0} Kills</span>
                  </div>
                  <div className="text-[11px] text-amber-400/90 font-mono mt-0.5">
                    Award: {tournament.prizes.mvpPrize || 'MVP Diamond Bonus'}
                  </div>
                </div>
              </div>

              {/* #1 Leader / Champion Showcase */}
              <div className="relative overflow-hidden rounded-xl bg-gradient-to-br from-amber-950/40 via-neutral-900 to-neutral-950 border border-amber-500/40 p-5 shadow-lg flex flex-col justify-between">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-bold text-amber-400 tracking-wider flex items-center gap-1.5">
                    <Trophy className="w-4 h-4 text-amber-400" />
                    <span>#1 BOOYAH LEADER</span>
                  </span>
                  <span className="text-xs font-mono px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold">
                    {standings[0].prizeMoney || '1st Place'}
                  </span>
                </div>
                <div className="my-2">
                  <div className="text-2xl font-black text-white font-display uppercase tracking-wide">
                    {standings[0].teamName}
                  </div>
                  <div className="text-xs text-neutral-400 font-mono">
                    Captain: {standings[0].captainName} · Slot #{standings[0].slotNumber}
                  </div>
                </div>
                <div className="flex items-center gap-4 text-xs font-mono text-neutral-300 border-t border-neutral-800/80 pt-2">
                  <span>Booyahs: <strong className="text-amber-400">{standings[0].booyahs}</strong></span>
                  <span>Kills: <strong className="text-orange-400">{standings[0].killPoints}</strong></span>
                  <span>Total: <strong className="text-amber-300 text-sm">{standings[0].totalPoints} pts</strong></span>
                </div>
              </div>

              {/* #2 & #3 Runner-up Strip */}
              <div className="rounded-xl bg-neutral-900 border border-neutral-800 p-5 flex flex-col justify-between">
                <div className="text-xs font-mono text-neutral-400 uppercase tracking-wider mb-2">
                  RUNNERS-UP PODIUM
                </div>
                {/* 2nd place */}
                <div className="flex items-center justify-between py-1.5 border-b border-neutral-800 text-xs">
                  <div className="flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-slate-400/20 text-slate-300 font-bold flex items-center justify-center font-mono text-[10px]">
                      2
                    </span>
                    <span className="font-bold text-white">{standings[1].teamName}</span>
                  </div>
                  <div className="font-mono text-neutral-300 font-bold">
                    {standings[1].totalPoints} pts
                  </div>
                </div>
                {/* 3rd place */}
                <div className="flex items-center justify-between py-1.5 text-xs">
                  <div className="flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-amber-700/20 text-amber-600 font-bold flex items-center justify-center font-mono text-[10px]">
                      3
                    </span>
                    <span className="font-bold text-white">{standings[2].teamName}</span>
                  </div>
                  <div className="font-mono text-neutral-300 font-bold">
                    {standings[2].totalPoints} pts
                  </div>
                </div>
                <div className="text-[11px] text-neutral-400 text-right font-mono mt-1">
                  Tiebreaker: Booyahs &gt; Placement &gt; Kills
                </div>
              </div>
            </div>
          )}

          {/* Points Table Container */}
          <div className="rounded-xl border border-neutral-800 bg-neutral-900/90 overflow-hidden shadow-xl">
            <div className="px-5 py-3.5 border-b border-neutral-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Trophy className="w-4 h-4 text-amber-500" />
                <h3 className="font-bold text-white font-display text-lg tracking-wide uppercase">
                  Official Standings Table
                </h3>
              </div>
              <div className="text-xs text-neutral-400 font-mono">
                {tournament.matches.filter((m) => m.isCompleted).length} / {tournament.matches.length} Matches Scored
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-neutral-800 bg-neutral-950/60 text-neutral-400 uppercase font-mono text-[11px] tracking-wider">
                    <th className="py-3 px-4 w-12 text-center">#</th>
                    <th className="py-3 px-4">Squad Name</th>
                    <th className="py-3 px-3 text-center">Slot</th>
                    <th className="py-3 px-3 text-center">Matches</th>
                    <th className="py-3 px-3 text-center text-amber-400 font-bold">Booyah 👑</th>
                    <th className="py-3 px-3 text-right">Place Pts</th>
                    <th className="py-3 px-3 text-right">Kill Pts</th>
                    <th className="py-3 px-4 text-right text-amber-400 font-bold text-sm">Total Pts</th>
                    <th className="py-3 px-4 text-right">Prize</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-800/60 font-mono-numbers">
                  {filteredStandings.map((s) => {
                    const isTop1 = s.rank === 1;
                    const isTop2 = s.rank === 2;
                    const isTop3 = s.rank === 3;

                    return (
                      <tr
                        key={s.slotNumber}
                        className={`hover:bg-neutral-800/40 transition-colors ${
                          isTop1 ? 'bg-amber-500/[0.04]' : ''
                        }`}
                      >
                        <td className="py-3 px-4 text-center">
                          {isTop1 ? (
                            <span className="inline-flex items-center justify-center w-6 h-6 rounded-md bg-amber-500 text-neutral-950 font-black text-xs shadow-sm">
                              1
                            </span>
                          ) : isTop2 ? (
                            <span className="inline-flex items-center justify-center w-6 h-6 rounded-md bg-slate-300 text-neutral-950 font-black text-xs">
                              2
                            </span>
                          ) : isTop3 ? (
                            <span className="inline-flex items-center justify-center w-6 h-6 rounded-md bg-amber-700 text-amber-100 font-black text-xs">
                              3
                            </span>
                          ) : (
                            <span className="text-neutral-500 font-semibold">{s.rank}</span>
                          )}
                        </td>
                        <td className="py-3 px-4">
                          <div className="font-sans font-bold text-sm text-white flex items-center gap-2">
                            <span>{s.teamName}</span>
                            <span className="text-[10px] font-mono px-1.5 py-0.2 bg-neutral-800 text-neutral-400 rounded">
                              {s.teamTag}
                            </span>
                          </div>
                          <div className="text-[11px] text-neutral-500 font-mono mt-0.5">
                            C: {s.captainName}
                          </div>
                        </td>
                        <td className="py-3 px-3 text-center text-neutral-400 font-mono">
                          Slot {s.slotNumber < 10 ? `0${s.slotNumber}` : s.slotNumber}
                        </td>
                        <td className="py-3 px-3 text-center text-neutral-300">
                          {s.matchesPlayed}
                        </td>
                        <td className="py-3 px-3 text-center text-amber-400 font-bold">
                          {s.booyahs > 0 ? `${s.booyahs}` : '-'}
                        </td>
                        <td className="py-3 px-3 text-right text-neutral-300">
                          {s.placementPoints}
                        </td>
                        <td className="py-3 px-3 text-right text-orange-400 font-semibold">
                          {s.killPoints}
                        </td>
                        <td className="py-3 px-4 text-right text-amber-400 font-extrabold text-sm">
                          {s.totalPoints}
                        </td>
                        <td className="py-3 px-4 text-right text-neutral-400 font-mono text-[11px]">
                          {s.prizeMoney ? (
                            <span className="text-amber-400 font-semibold bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                              {s.prizeMoney}
                            </span>
                          ) : (
                            '-'
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>

              {filteredStandings.length === 0 && (
                <div className="py-12 text-center text-neutral-500 font-mono text-xs">
                  {lang === 'ur' ? 'Koi team nahi mili' : 'No teams match your search.'}
                </div>
              )}
            </div>

            {/* Official Scoring Reference footer */}
            <div className="px-5 py-3 bg-neutral-950/80 border-t border-neutral-800 flex flex-wrap items-center justify-between gap-3 text-[11px] text-neutral-400 font-mono">
              <div>
                <strong className="text-neutral-300">Point System:</strong> #1=12pts · #2=9pts · #3=8pts · #4=7pts · #5=6pts · #6=5pts · #7=4pts · #8=3pts · #9=2pts · #10=1pt · Kill=1pt
              </div>
              <div className="text-amber-400">
                Official Free Fire Esports Rulebook
              </div>
            </div>
          </div>
        </div>
      )}

      {/* INDIVIDUAL MATCH BREAKDOWN VIEW */}
      {selectedTab !== 'overall' && selectedMatch && (
        <div className="space-y-6">
          {/* Match Banner Card */}
          <div className="rounded-xl border border-neutral-800 bg-neutral-900 p-5 shadow-lg flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 text-xs font-mono text-amber-400 mb-1">
                <span>MATCH #{selectedMatch.matchNumber}</span>
                <span>·</span>
                <span className="uppercase">{selectedMatch.map} MAP</span>
                <span>·</span>
                <span>{selectedMatch.startTime}</span>
              </div>
              <h2 className="text-2xl font-black text-white font-display uppercase tracking-wide">
                {selectedMatch.map} Combat Results
              </h2>
              {selectedMatch.notes && (
                <p className="text-xs text-neutral-400 mt-1 max-w-xl">
                  {selectedMatch.notes}
                </p>
              )}
            </div>

            <div className="flex items-center gap-2">
              {isAdmin && (
                <>
                  <button
                    onClick={() => onEditMatch(selectedMatch)}
                    className="px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 border border-neutral-700 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors"
                  >
                    <Edit3 className="w-3.5 h-3.5 text-amber-400" />
                    <span>Edit Scores</span>
                  </button>
                  <button
                    onClick={() => onDeleteMatch(selectedMatch.id)}
                    className="p-1.5 text-neutral-400 hover:text-red-400 border border-neutral-800 rounded-lg hover:bg-neutral-800 transition-colors"
                    title="Delete Match"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </>
              )}
            </div>
          </div>

          {/* Match MVP Banner (if assigned) */}
          {selectedMatch.matchMvp && (
            <div className="rounded-xl bg-amber-500/10 border border-amber-500/30 p-4 flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-amber-500 text-neutral-950 font-black flex items-center justify-center font-display text-xl">
                  MVP
                </div>
                <div>
                  <div className="text-xs font-mono text-amber-400 font-semibold uppercase">
                    MATCH TOP FRAGGER
                  </div>
                  <div className="text-base font-bold text-white font-display">
                    {selectedMatch.matchMvp.playerIgn} ({selectedMatch.matchMvp.teamName})
                  </div>
                </div>
              </div>
              <div className="text-right font-mono">
                <div className="text-lg font-black text-amber-400">
                  {selectedMatch.matchMvp.kills} KILLS
                </div>
                {selectedMatch.matchMvp.damage && (
                  <div className="text-xs text-neutral-400">{selectedMatch.matchMvp.damage} Damage</div>
                )}
              </div>
            </div>
          )}

          {/* Match Scores Table */}
          {selectedMatch.results.length > 0 ? (
            <div className="rounded-xl border border-neutral-800 bg-neutral-900/90 overflow-hidden shadow-xl">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-neutral-800 bg-neutral-950/60 text-neutral-400 uppercase font-mono text-[11px]">
                    <th className="py-3 px-4 w-12 text-center">Place</th>
                    <th className="py-3 px-4">Team</th>
                    <th className="py-3 px-3 text-center">Slot</th>
                    <th className="py-3 px-3 text-center">Booyah</th>
                    <th className="py-3 px-3 text-right">Kills</th>
                    <th className="py-3 px-3 text-right">Place Pts</th>
                    <th className="py-3 px-3 text-right">Kill Pts</th>
                    <th className="py-3 px-4 text-right text-amber-400 font-bold text-sm">Match Pts</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-800/60 font-mono-numbers">
                  {selectedMatch.results
                    .sort((a, b) => a.placement - b.placement)
                    .map((res) => {
                      const isBooyah = res.placement === 1;
                      return (
                        <tr
                          key={res.slotNumber}
                          className={`hover:bg-neutral-800/40 transition-colors ${
                            isBooyah ? 'bg-amber-500/[0.05]' : ''
                          }`}
                        >
                          <td className="py-3 px-4 text-center font-bold">
                            {isBooyah ? (
                              <span className="inline-flex items-center justify-center w-6 h-6 rounded-md bg-amber-500 text-neutral-950 font-black text-xs">
                                #1
                              </span>
                            ) : (
                              <span className="text-neutral-400">#{res.placement}</span>
                            )}
                          </td>
                          <td className="py-3 px-4">
                            <span className="font-sans font-bold text-white text-sm">
                              {res.teamName}
                            </span>
                            {res.mvpPlayer && (
                              <span className="ml-2 text-[10px] text-amber-400 font-mono px-1.5 py-0.5 bg-amber-500/15 rounded border border-amber-500/30">
                                MVP: {res.mvpPlayer} ({res.mvpKills}k)
                              </span>
                            )}
                          </td>
                          <td className="py-3 px-3 text-center text-neutral-400 font-mono">
                            Slot {res.slotNumber}
                          </td>
                          <td className="py-3 px-3 text-center font-mono">
                            {isBooyah ? (
                              <span className="text-amber-400 font-bold">👑 BOOYAH!</span>
                            ) : (
                              '-'
                            )}
                          </td>
                          <td className="py-3 px-3 text-right text-orange-400 font-bold">
                            {res.kills}
                          </td>
                          <td className="py-3 px-3 text-right text-neutral-300">
                            {res.placementPoints}
                          </td>
                          <td className="py-3 px-3 text-right text-orange-400">
                            {res.killPoints}
                          </td>
                          <td className="py-3 px-4 text-right text-amber-400 font-black text-sm">
                            {res.totalPoints}
                          </td>
                        </tr>
                      );
                    })}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="rounded-xl border border-neutral-800 bg-neutral-900/60 p-12 text-center">
              <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center mx-auto mb-3">
                <Target className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-white font-display uppercase tracking-wide">
                Match Not Scored Yet
              </h3>
              <p className="text-xs text-neutral-400 mt-1 max-w-md mx-auto">
                Match khatam hone par host yahan scores enter karega.
              </p>
              {isAdmin && (
                <button
                  onClick={() => onEditMatch(selectedMatch)}
                  className="mt-4 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold text-xs rounded-lg font-display uppercase tracking-wider inline-flex items-center gap-2"
                >
                  <Edit3 className="w-4 h-4" />
                  <span>Enter Match Scores</span>
                </button>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
