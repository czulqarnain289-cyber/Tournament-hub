# Free Fire Esports Tournament Hub - Vercel Deployment Guide

Yeh code Vercel par 1-Click host hone ke liye mukammal tayar hai.
Is code ko Vercel par host karne ke baad aapko **Free Lifetime Permanent Link** (e.g. `https://your-tournament.vercel.app`) mil jayega jo kisi bhi player ke phone par bina kisi error (No 404, No Login barrier) ke foran khulega!

---

## 🚀 Vercel Par Host Karne Ka Aasan Tarika (3 Steps)

### Tarika 1: GitHub + Vercel (Sab Se Best & Recommended)
1. **GitHub par Repository banayein:**
   - [github.com](https://github.com) par jayein aur **New Repository** banayein (e.g. `freefire-tournament`).
   - Is ZIP ko extract kar ke saari files GitHub repository me upload kar dein.

2. **Vercel par Import karein:**
   - [vercel.com](https://vercel.com) par free account banayein (apne Google ya GitHub account se).
   - **"Add New..."** -> **"Project"** par click karein.
   - Apni GitHub repository select karein aur **Import** dabayein.

3. **Deploy Settings:**
   - **Framework Preset**: `Vite` (Vercel automatically detect kar leta hai)
   - **Root Directory**: `./`
   - **Build Command**: `npm run build`
   - **Output Directory**: `dist`
   - **Deploy** button daba dein! 1 minute me aapka live link tayar ho jayega!

---

### Tarika 2: Vercel CLI (Direct Computer Se)
Agar aapke computer me Node.js install hai:
```bash
# 1. Folder me terminal kholein
cd freefire-tournament

# 2. Vercel CLI install & deploy
npm i -g vercel
vercel
```
Aur screen par diye gaye prompts par `Enter` press karein.

---

## 🛡️ Host & Admin Information
- **Admin Secret PIN**: `7860` (Is PIN se Host slots manage karega aur match record karega)
- **Player View**: Players bina PIN ke sirf Results, Points Table, Slot List aur Registration Form dekh sakte hain.
- **WhatsApp Share**: In-built WhatsApp buttons se direct groups me slot list aur points table share ho sakti hai.
